<?php

namespace LegendDevelopment\Theme\Providers;

use App\Models\Role;
use BladeUI\Icons\Factory as IconFactory;
use Filament\Support\Facades\FilamentView;
use Filament\View\PanelsRenderHook;
use Illuminate\Auth\Events\Login as SignedIn;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\HtmlString;
use Illuminate\Support\ServiceProvider;
use LegendDevelopment\Theme\Filament\Profile\ApiTab;
use LegendDevelopment\Theme\Http\ApiController;
use LegendDevelopment\Theme\Http\FavouriteController;
use LegendDevelopment\Theme\Http\LayoutController;
use LegendDevelopment\Theme\Http\PayController;
use LegendDevelopment\Theme\Http\QuickController;
use LegendDevelopment\Theme\Http\ShopController;
use LegendDevelopment\Theme\Http\StatusController;
use LegendDevelopment\Theme\Http\TicketController;
use LegendDevelopment\Theme\Support\Access\RoleServers;
use LegendDevelopment\Theme\Support\Access\Sync;
use LegendDevelopment\Theme\Support\Areas;
use LegendDevelopment\Theme\Support\Attention;
use LegendDevelopment\Theme\Support\Alerts\Schedule as AlertSchedule;
use LegendDevelopment\Theme\Support\AutoUpdate;
use LegendDevelopment\Theme\Support\Background;
use LegendDevelopment\Theme\Support\Cdn\Mirror;
use LegendDevelopment\Theme\Support\Bars;
use LegendDevelopment\Theme\Support\CustomCss;
use LegendDevelopment\Theme\Support\IconPacks;
use LegendDevelopment\Theme\Support\Icons;
use LegendDevelopment\Theme\Support\Layout;
use LegendDevelopment\Theme\Support\Layouts;
use LegendDevelopment\Theme\Support\Login;
use LegendDevelopment\Theme\Support\NavLinks;
use LegendDevelopment\Theme\Support\Notice;
use LegendDevelopment\Theme\Support\Presets;
use LegendDevelopment\Theme\Support\Quick;
use LegendDevelopment\Theme\Support\Preview;
use LegendDevelopment\Theme\Support\Runtime;
use LegendDevelopment\Theme\Support\ServerConsole;
use LegendDevelopment\Theme\Support\Stamp;
use LegendDevelopment\Theme\Support\ServerControls;
use LegendDevelopment\Theme\Support\Favourites;
use LegendDevelopment\Theme\Support\Api\Keys;
use LegendDevelopment\Theme\Support\Shop\Tables;
use LegendDevelopment\Theme\Support\Shop\Schedule as ShopSchedule;
use LegendDevelopment\Theme\Support\Features;
use LegendDevelopment\Theme\Support\InstallTasks;
use LegendDevelopment\Theme\Support\FullPreview;
use LegendDevelopment\Theme\Support\ServerList;
use LegendDevelopment\Theme\Support\SidebarFooter;
use LegendDevelopment\Theme\Support\Terminal;
use LegendDevelopment\Theme\Support\Typography;
use LegendDevelopment\Theme\Support\Updating;
use LegendDevelopment\Theme\Support\UserTheme;
use LegendDevelopment\Theme\Support\Windows;
use LegendDevelopment\Theme\Support\Theme;
use LegendDevelopment\Theme\Support\Tickets\Board;
use LegendDevelopment\Theme\Support\Tickets\Button as TicketButton;
use LegendDevelopment\Theme\Support\Workers;
use Throwable;

class ThemeServiceProvider extends ServiceProvider
{
    /** The settings block, built once and handed back to every re-fire. */
    private static ?string $settings = null;

    private static ?string $stylesheet = null;

    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Before the permissions: the icon they are registered with is a name
        // out of this set, and a name from a set nobody registered draws nothing.
        $this->registerIconSet();

        // The permissions and the Theme page are registered either way, so the
        // theme can be switched back on from a panel that currently renders
        // completely untouched.
        $this->registerPermissions();
        $this->registerAutoUpdate();

        /*
         * Before the return below, and that is a fix rather than tidying.
         *
         * These are where the page arranger and the stars on the server
         * cards save to. They were registered further down, past the point
         * where a panel with the styling switched off stops reading this
         * method - so on such a panel the stars drew, the browser posted
         * them, and the post hit nothing at all. Neither feature has
         * anything to do with whether the theme is painting.
         */
        $this->registerLayoutRoute();
        $this->registerApiRoutes();

        /*
         * And the shop's, for the same reason: a public shop page and a
         * printable invoice have nothing to do with whether this panel is
         * being painted by the theme.
         */
        /*
         * Columns this version has and the database does not, before anything
         * reads them. One cache read on an ordinary request - see
         * InstallTasks::schema() for why an install is not enough on its own.
         */
        InstallTasks::schema();

        $this->registerShopRoutes();
        $this->registerTicketRoutes();

        /*
         * And this one, also before the return: whether the panel is being
         * painted has nothing to do with whether somebody's role should have
         * given them a server.
         */
        $this->registerAccessSync();
        $this->registerServerListWidget();
        $this->registerProfileTab();

        // Above the return below, beside the routes and the schema check: an
        // update happens whether or not this panel is being painted by the
        // theme, and the line that explains it is not part of the styling.
        Updating::register();

        if (Presets::isDisabled()) {
            return;
        }

        // STYLES_AFTER puts the theme behind Pelican's own stylesheet, which is
        // registered on STYLES_BEFORE. Registering here rather than in the plugin
        // class means the hook is added once, not once per panel.
        FilamentView::registerRenderHook(
            PanelsRenderHook::STYLES_AFTER,
            // The administrator's own CSS goes last of all, so it needs no
            // !important to win from anything the theme itself emitted.
            fn () => new HtmlString(
                $this->stylesheet() . $this->settings() . CustomCss::style() . Runtime::script(),
            ),
        );

        FilamentView::registerRenderHook(
            PanelsRenderHook::SCRIPTS_AFTER,
            fn () => new HtmlString($this->script()),
        );

        // One line across the top of the panel. Static markup in the first
        // response, for the reason spelled out in Notice::html().
        FilamentView::registerRenderHook(
            PanelsRenderHook::PAGE_START,
            fn () => new HtmlString($this->notice()),
        );

        /*
         * And a way to ask for help, in the corner of every page.
         *
         * At the end of the body rather than in the page, so it sits above
         * whatever the page drew and is in the same place wherever somebody is
         * - which is the whole point of it. Button::html() decides whether
         * there is anything to draw at all.
         *
         * The hook is named by its string rather than through the constant,
         * for the reason written on the login screen's hooks below: a constant
         * a future Filament renames is a fatal on every page, and a string it
         * no longer recognises is a hook nobody renders. A button in a corner
         * is exactly the kind of thing that should fail that way round.
         */
        FilamentView::registerRenderHook(
            'panels::body.end',
            static fn () => new HtmlString(TicketButton::html()),
        );

        /*
         * The sign-in screen: a line above the form, and links under it.
         *
         * The hook names are written out rather than taken from
         * PanelsRenderHook, deliberately. A constant that a future Filament
         * renames is a fatal on every page; a string it no longer recognises is
         * simply a hook nobody renders. On a login screen, the second is the
         * only acceptable way to be wrong.
         */
        if (Features::enabled(Features::LOGIN)) {
            FilamentView::registerRenderHook(
                'panels::auth.login.form.before',
                fn () => new HtmlString($this->attempt(fn (): string => Login::above())),
            );

            FilamentView::registerRenderHook(
                'panels::auth.login.form.after',
                fn () => new HtmlString($this->attempt(fn (): string => Login::links())),
            );
        }

        // The bottom of the sidebar, which Pelican leaves empty. Wrapped like
        // the announcement bar: a hook that throws takes every page with it,
        // and a line of text is not worth that.
        FilamentView::registerRenderHook(
            SidebarFooter::HOOK,
            fn () => new HtmlString($this->attempt(fn (): string => SidebarFooter::html())),
        );

        if (Features::enabled(Features::BARS)) {
            Bars::register();
        }

        /*
         * One control in the top bar: where next.
         *
         * The hook name is written out rather than taken from PanelsRenderHook
         * for the reason given above the login hooks - but unlike those it was
         * read from Filament's own source before being used rather than
         * remembered, so this is a string by policy and not by hope.
         *
         * global-search.after, and the choice is exact rather than approximate.
         * Filament's topbar puts the search box, the notifications bell and the
         * account menu inside one flex row, .fi-topbar-end, and renders
         * topbar.end *after* that row closes. So topbar.end put this past the
         * avatar, at the far edge, away from the group it belongs to.
         * global-search.after is the last hook inside the row and lands
         * immediately before the bell - which is where somebody looks for their
         * own shortcuts, next to their own notifications and their own account.
         *
         * That row also carries x-persist, so this survives a Livewire
         * navigation rather than being rebuilt with the page. Nothing here
         * depends on that: every listener is on the document. It is simply
         * cheaper.
         */
        if (Features::maySee(Features::QUICK)) {
            FilamentView::registerRenderHook(
                'panels::global-search.after',
                fn () => new HtmlString($this->attempt(fn (): string => Quick::html())),
            );
        }

        // The power buttons and the way back to the console, on every page
        // inside a server. Its own render hook, registered once here.
        ServerControls::register();
    }

    /**
     * The announcement bar. Wrapped, because a render hook that throws takes
     * every page with it, and a line of text is not worth that.
     */
    private function notice(): string
    {
        /*
         * The preview bar first, and outside the announcements switch.
         *
         * It is not an announcement - it is the page saying what it is. A panel
         * showing colours that are not saved has to say so on every page,
         * including one where the administrator has switched announcements off,
         * or the preview becomes indistinguishable from the panel and somebody
         * spends an afternoon wondering why a setting will not stick.
         */
        $bar = $this->attempt(fn (): string => FullPreview::html());

        if (!Features::enabled(Features::ANNOUNCEMENTS)) {
            return $bar;
        }

        return $bar . $this->attempt(fn (): string => Notice::html());
    }

    /**
     * A render that is allowed to fail without taking the page with it.
     *
     * The fallback is a parameter, and that is a fix rather than a flourish.
     * This used to be `attempt(callable): string` while the same method in
     * three other classes here was `attempt(callable, mixed): mixed` - so a
     * call written in the shape of its three siblings compiled, ran, and was
     * wrong in a way nothing reported.
     *
     * What happened is worth writing down. PHP does not object to extra
     * arguments passed to a userland function, so the fallback was accepted and
     * silently dropped. The closure then returned an array, the `: string`
     * return type could not coerce it, and the TypeError was thrown *at the
     * return statement* - which is inside the try below. So it was caught by
     * the very handler meant for a failing render, and the caller was handed
     * '' instead of a list.
     *
     * The visible result was that every starred server vanished on reload:
     * Favourites::for() was read correctly, turned into an empty string on the
     * way out, and the browser drew from an empty list - then saved that list
     * back over the real one on the next click.
     *
     * @param  callable(): mixed  $render
     */
    private function attempt(callable $render, mixed $fallback = ''): mixed
    {
        try {
            return $render();
        } catch (Throwable) {
            return $fallback;
        }
    }

    /**
     * Hands the automatic update check to the scheduler, and only where the
     * scheduler exists - resolving it for every web request would be building
     * something nothing is going to read.
     */
    private function registerAutoUpdate(): void
    {
        if (!$this->app->runningInConsole()) {
            return;
        }

        // After booting: the schedule is resolved once the rest of the panel is
        // up, so reading the setting cannot land before config is in place.
        $this->app->booted(function (): void {
            try {
                $schedule = $this->app->make(Schedule::class);

                /*
                 * A mark saying the cron ran, and nothing else.
                 *
                 * Its own entry rather than a line inside one of the checks
                 * below, because those are switched off, run every fifteen
                 * minutes, or both - and a mark refreshed every quarter hour
                 * cannot answer "has the scheduler stopped" without crying wolf
                 * every quarter hour. It was written inside the watchdog first
                 * and did exactly that.
                 *
                 * Registered whatever is switched off, because the question it
                 * answers is about the panel and not about any feature: a cron
                 * that is not running takes renewals, watchdog passes and
                 * automatic updates with it. One cache write a minute.
                 */
                $schedule->call(static fn () => Workers::ticked())
                    ->name('legend-theme:tick')
                    ->everyMinute();

                AutoUpdate::schedule($schedule);

                // The watchdog rides the same cron entry Pelican already
                // requires. Registered beside the updater rather than in its
                // own place, because there is only one scheduler and both of
                // them fail the same way if it is not running.
                AlertSchedule::register($schedule);

                // The public status page, rebuilt every minute so what a
                // visitor sees is a minute old at worst rather than however
                // long ago somebody last opened it.
                /*
                 * Anything said at the far end of a ticket.
                 *
                 * A quarter of an hour, and only for tickets that are still
                 * open and have actually been passed on. Reading one on either
                 * page pulls it first, so this is the pass that reaches the
                 * customer who is not looking - which is the whole reason it
                 * exists, and also why a minute would be far too often.
                 *
                 * Skipped entirely by the panel's own desk, whose pull() does
                 * nothing: no request, no work, no entry in the log.
                 */
                $schedule->call(static function (): void {
                    foreach (Board::stale() as $ticket) {
                        Board::pull($ticket);
                    }
                })
                    ->name('legend-theme:tickets')
                    ->withoutOverlapping(30)
                    ->everyFifteenMinutes();

                /*
                 * And anything that has not reached the desk yet.
                 *
                 * Its own entry, five minutes apart rather than fifteen,
                 * because what it catches is a race and not a silence: Modora
                 * makes the Discord channel after it says the ticket exists, so
                 * a first message sent straight afterwards is refused with
                 * "retry in a moment". Fifteen minutes is a long moment for
                 * somebody who has just asked a question.
                 *
                 * Cheap when there is nothing to do, which is the ordinary
                 * case: behind() is one query and usually returns nothing.
                 */
                $schedule->call(static function (): void {
                    foreach (Board::behind() as $ticket) {
                        Board::retry($ticket);
                    }
                })
                    ->name('legend-theme:tickets-catchup')
                    ->withoutOverlapping(10)
                    ->everyFiveMinutes();

                /*
                 * And the off-panel copy of any language somebody uploaded.
                 *
                 * Every minute by default, and almost every minute does
                 * nothing: it reads what is installed, hashes it, finds the
                 * hash unchanged and stops. The timer decides when to look
                 * rather than when to send, which is what makes a minute an
                 * affordable interval for several hundred kilobytes.
                 *
                 * Registered only when there is somewhere to send to and
                 * something to send, so a panel with no CDN has no entry at
                 * all rather than one that wakes up to decide it has nothing
                 * to do.
                 */
                if (Mirror::ready()) {
                    $schedule->call(static fn () => Mirror::push())
                        ->name('legend-theme:translations')
                        ->withoutOverlapping(5)
                        ->cron('*/' . Mirror::minutes() . ' * * * *');
                }

                AlertSchedule::status($schedule);

                // Servers tied to a role. On the same cron entry as the rest,
                // and only worth a quarter hour because saving the mapping and
                // signing in both reconcile on their own - the timer is here
                // for the third case, somebody being given a role.
                Sync::schedule($schedule);

                // And the shop's daily pass: next period's invoices written a
                // few days early, servers stopped when one goes unpaid past
                // the grace period. Daily because both are measured in days.
                ShopSchedule::register($schedule);
            } catch (Throwable) {
                // Never let a scheduling problem stop artisan from running.
            }
        });
    }

    /**
     * A tab on Pelican's own profile page, where people look for API keys.
     *
     * `?tab=api-keys::data::tab` is where Pelican keeps them, and this plugin
     * kept its own somewhere else entirely - so the answer to "where do I get a
     * key" depended on knowing there were two kinds. It is offered in both
     * places now, and the one that is easier to find makes the narrower key.
     *
     * Guarded on class_exists and method_exists for the reason written on the
     * server list widget below: this names a class inside Pelican by its full
     * path, and an Error thrown from a plugin boot is not caught by Pelican's
     * loader - it is a 500 on every page rather than a missing tab. That fault
     * has shipped from this plugin once already.
     *
     * The Tab is built here, at boot, so everything on it that reads a
     * translation is a closure. A label resolved now is one asked for before
     * the language of whoever is reading it is known.
     */
    private function registerProfileTab(): void
    {
        try {
            if (!Features::enabled(Features::API)) {
                return;
            }

            $page = 'App\Filament\Pages\Auth\EditProfile';
            $position = 'App\Enums\TabPosition';

            if (!class_exists($page) || !class_exists($position) || !method_exists($page, 'registerCustomTabs')) {
                return;
            }

            $page::registerCustomTabs($position::After, ApiTab::make());
        } catch (Throwable $exception) {
            report($exception);
        }
    }

    /**
     * The backup warning above somebody's own server list.
     *
     * **A render hook rather than a header widget, and that is the fourth
     * attempt at this.** A widget lands in Filament's widget grid, which is two
     * columns wide, so a one-line warning about twenty-five servers was drawn
     * down half the page in a column beside nothing. Three stylesheet attempts
     * to widen it all failed, each looking like the last, and the fourth would
     * have been another guess at a wrapper this codebase cannot inspect.
     *
     * The announcement bar has been full width since it shipped because it is
     * rendered at PAGE_START and never goes near that grid. So this is too.
     *
     * **Scoped to the server list**, which is what makes a page-level hook
     * acceptable: without the scope this would be a bar on every page of the
     * client area. The page is named by string and guarded with class_exists
     * for the reason below - a class named by its full Pelican path is a class
     * that can move, and an Error thrown here is not caught by Pelican's plugin
     * loader, which catches Exception.
     *
     * The failure mode if Pelican renames that page is the warning not being
     * drawn. That is the right way for this to be wrong.
     */
    private function registerServerListWidget(): void
    {
        try {
            if (!Features::enabled(Features::MY_BACKUPS)) {
                return;
            }

            $page = 'App\Filament\App\Resources\Servers\Pages\ListServers';

            if (!class_exists($page)) {
                return;
            }

            FilamentView::registerRenderHook(
                PanelsRenderHook::PAGE_START,
                function (): HtmlString {
                    if (!Attention::enabled()) {
                        return new HtmlString('');
                    }

                    return new HtmlString(
                        (string) view(Theme::id() . '::components.my-backups')->render()
                    );
                },
                scopes: $page,
            );
        } catch (Throwable $exception) {
            report($exception);
        }
    }

    /**
     * Reconcile one person's role servers as they sign in.
     *
     * The timer catches a role somebody was given an hour ago; this catches the
     * moment they would notice. It asks about one person rather than about
     * everybody, so it is a handful of queries rather than a sweep, and it is
     * wrapped because a sign-in must not fail over this - somebody locked out
     * of the panel by an access feature would be the worst possible way for
     * this to go wrong.
     */
    private function registerAccessSync(): void
    {
        /*
         * Aliased, and not for neatness: this file already imports a Login -
         * the plugin's own, for the sign-in screen - and two classes under one
         * short name is the fault tools/check-classes.js exists to catch.
         */
        Event::listen(SignedIn::class, static function (SignedIn $event): void {
            try {
                if (!RoleServers::enabled() || RoleServers::rows() === []) {
                    return;
                }

                $id = $event->user->getAuthIdentifier();

                if (is_numeric($id)) {
                    Sync::one((int) $id);
                }
            } catch (Throwable $exception) {
                report($exception);
            }
        });
    }

    /**
     * Where the page arranger saves to. Registered outside the panels because it
     * is a plain endpoint, not a page.
     */
    private function registerLayoutRoute(): void
    {
        try {
            /*
             * Each behind its own feature, the way the API route is.
             *
             * These were registered whatever the settings said, on the argument
             * that a switched-off feature loads no script so nothing calls
             * them. True, and beside the point: an endpoint nothing calls is
             * still an endpoint, and this plugin already decided elsewhere that
             * a closed door and a locked one are different amounts of surface.
             * Switching something off should take its route with it.
             */
            if (Features::enabled(Features::ARRANGER)) {
                Route::middleware(['web', 'auth'])
                    ->post('/legend-theme/layout', LayoutController::class);
            }

            // The stars on the server cards. Behind the same middleware: it
            // writes a file belonging to whoever is signed in, so there has to
            // be somebody signed in.
            if (Features::enabled(Features::FAVOURITES)) {
                Route::middleware(['web', 'auth'])
                    ->post('/legend-theme/favourites', FavouriteController::class);
            }

            /*
             * What the top bar's switcher shows when it is opened.
             *
             * A GET, because it changes nothing - and behind auth, because what
             * it answers with is the list of servers this person may open. It
             * asks accessibleServers() rather than deciding that itself, so it
             * can only ever show somebody what Pelican would already show them.
             */
            if (Features::enabled(Features::QUICK)) {
                Route::middleware(['web', 'auth'])
                    ->get('/legend-theme/quick', QuickController::class);
            }

            /*
             * The one route with no auth on it.
             *
             * Which is the entire point of a status page - somebody whose
             * server has stopped does not have an account on the panel. It is
             * throttled instead: the page is served from a snapshot and cannot
             * reach a node on its own, but a route anybody may call still
             * deserves a ceiling. Sixty a minute per address is far above what
             * a person does and far below what a script does.
             *
             * StatusController answers 404 unless an administrator has named at
             * least one server, so on a panel that changed nothing this route
             * exists and serves nothing.
             */
            Route::middleware(['web', 'throttle:60,1'])
                ->get('/status', StatusController::class)
                ->name('legend-theme.status');

            /*
             * And one page per person, at a slug they chose.
             *
             * The pattern is on the route rather than only in the controller,
             * so a request for /status/../../etc never reaches PHP at all. The
             * controller checks it again before looking anything up, because a
             * route constraint is a filter and not a promise about what a
             * string contains.
             */
            Route::middleware(['web', 'throttle:60,1'])
                ->get('/status/{slug}', [StatusController::class, 'user'])
                ->where('slug', '[a-z0-9][a-z0-9-]{1,31}')
                ->name('legend-theme.status.user');
        } catch (Throwable) {
            // Routes are cached; `php artisan optimize:clear` brings it back.
        }
    }

    /**
     * Adds a "Legend Theme" section with View and Update checkboxes to the role
     * editor. Pelican creates the permission records itself the first time a
     * role is saved with them ticked, so there is nothing to seed.
     */
    /**
     * The two shop pages that live outside the panel.
     *
     * **The public shop**, at /shop, for somebody who has not signed in. Behind
     * both switches - the shop itself and the public page - so an administrator
     * who wants the shop for logged-in customers only gets no public route at
     * all rather than one answering 404 from the controller. Throttled the way
     * the status page is: sixty a minute per address is far above what a person
     * does and far below what a script does.
     *
     * **The printable invoice**, behind web and auth, because it is somebody's
     * own document. The controller checks who is asking; the middleware is what
     * makes sure there is somebody to check.
     *
     * The client-side pages - the store, the checkout, the billing page - are
     * Filament pages inside the panel and need no route here. Their slugs are
     * store, checkout and billing rather than shop: the client panel is mounted
     * at the site root on a default Pelican install, and a page called shop
     * would sit exactly where this route does.
     */
    /**
     * The address Modora posts ticket events to.
     *
     * No `web` and no `auth`, like the payment webhooks and for the same
     * reason: the caller is somebody else's server with no session, and a
     * forgery token in front of a machine refuses every one of them. What
     * replaces them here is the address itself, which carries a long random
     * secret - and Hook, which will only ever add to a conversation this panel
     * already started.
     *
     * Registered whatever desk is chosen. A panel that switches to Modora and
     * back should not have to think about whether an address still answers, and
     * a delivery for a ticket this panel never pushed finds nothing anyway.
     */
    private function registerTicketRoutes(): void
    {
        try {
            if (!Features::enabled(Features::TICKETS)) {
                return;
            }

            Route::middleware(['throttle:300,1'])
                ->post('/essentials/tickets/hook/{secret}', [TicketController::class, 'hook'])
                ->where('secret', '[a-f0-9]{16,96}')
                ->name('legend-theme.tickets.hook');

            /*
             * A picture somebody attached to a ticket.
             *
             * No `auth`, and it cannot have any: the thing fetching it is
             * Discord's server, which has no account here and never will. The
             * address is unguessable instead - thirty-two hex characters that
             * say nothing about the ticket, the customer or the order they were
             * uploaded in.
             *
             * It is also the narrowest thing this plugin serves: one route that
             * only ever hands back an image it wrote itself, with the type read
             * from the bytes rather than from anything a request said.
             */
            Route::middleware(['throttle:240,1'])
                ->get('/essentials/tickets/file/{token}', [TicketController::class, 'file'])
                ->where('token', '[0-9a-f]{32}\\.[a-z0-9]{1,8}')
                ->name('legend-theme.tickets.file');
        } catch (Throwable) {
            // A route that could not be registered is a webhook that does not
            // answer, and the quarter-hourly pull is exactly the net for that.
        }
    }

    private function registerShopRoutes(): void
    {
        try {
            if (!Features::enabled(Features::SHOP) || !Tables::ready()) {
                return;
            }

            if (Features::enabled(Features::PUBLIC_SHOP)) {
                Route::middleware(['web', 'throttle:60,1'])
                    ->get('/shop', ShopController::class)
                    ->name('legend-theme.shop');
            }

            /*
             * The file a customer uploaded, for the daemon that is about to put
             * it in their server.
             *
             * No `web` and no `auth`, deliberately, and for the same reason the
             * payment webhooks have neither: the caller is a machine with no
             * session. `signed` is what replaces them - the address carries a
             * signature Laravel made with the app key and an expiry an hour
             * out, so it cannot be forged and it cannot be replayed tomorrow.
             */
            Route::middleware(['signed', 'throttle:60,1'])
                ->get('/essentials/upload/{order}', [ShopController::class, 'upload'])
                ->where('order', '[0-9]+')
                ->name('legend-theme.upload');

            Route::middleware(['web', 'auth'])
                ->get('/essentials/invoice/{id}', [ShopController::class, 'invoice'])
                ->where('id', '[0-9]+')
                ->name('legend-theme.invoice');

            /*
             * And the two a payment provider needs.
             *
             * The webhook has no `web` middleware on purpose. It is a POST from
             * somebody else's server, the way this plugin's API routes are
             * requests from a bot, and a session cookie and a forgery token in
             * front of a machine would simply refuse every one of them. What
             * replaces it is that nothing in the body is believed: the provider
             * is asked over an authenticated connection what happened. The
             * throttle is a ceiling on an address that anybody may call.
             *
             * The return address is behind auth, because it is the customer
             * coming back and the page it leads to is theirs.
             */
            if (Features::enabled(Features::PAYMENTS)) {
                Route::middleware(['throttle:120,1'])
                    ->post('/essentials/pay/{gateway}/webhook', [PayController::class, 'hook'])
                    ->where('gateway', '[a-z]{2,24}')
                    ->name('legend-theme.pay.webhook');

                Route::middleware(['web', 'auth'])
                    ->get('/essentials/pay/{gateway}/return/{invoice}', [PayController::class, 'back'])
                    ->where('gateway', '[a-z]{2,24}')
                    ->where('invoice', '[0-9]+')
                    ->name('legend-theme.pay.return');
            }
        } catch (Throwable) {
            // Routes are cached; `php artisan optimize:clear` brings it back.
        }
    }

    /**
     * The API, when a panel has asked for one.
     *
     * **Registered only while the feature is on.** Off leaves no route at all
     * rather than one answering 403, which is a smaller thing to have than a
     * politely closed one - and it means the switch on the settings page is the
     * whole of the off switch, with nothing listening behind it.
     *
     * **No middleware group.** Pelican's own `api` group is
     * EnsureStatefulRequests, auth:sanctum, IsValidJson, TrackAPIKey and
     * AuthenticateIPAccess - read from its bootstrap/app.php rather than
     * assumed - so using it would put this behind a *Pelican* key and the
     * plugin's own key would never be looked at. `web` would be worse: session,
     * cookies and forgery protection on an endpoint a bot calls with no
     * browser. What is left is a throttle and nothing else, which is what an
     * endpoint that authenticates itself actually wants.
     *
     * The ceiling here is a floor, not the setting. It is per address and
     * generous, and exists so an unauthenticated flood costs something before
     * anything reads a key. The real per-key limit is in the controller, where
     * it can change without the routes being rebuilt.
     */
    private function registerApiRoutes(): void
    {
        try {
            if (!Keys::enabled()) {
                return;
            }

            $base = '/api/essentials/' . ApiController::CONTRACT;

            /*
             * One route a question. Written out rather than looped over a list,
             * because tools/check-api-docs.js reads these lines against
             * Docs::endpoints() and a loop would hide from it exactly what it
             * exists to compare.
             */
            Route::middleware(['throttle:120,1'])->group(static function () use ($base): void {
                Route::get($base . '/health', [ApiController::class, 'health'])->name('essentials.api.health');
                Route::get($base . '/nodes', [ApiController::class, 'nodes'])->name('essentials.api.nodes');
                Route::get($base . '/system', [ApiController::class, 'host'])->name('essentials.api.system');
                Route::get($base . '/backups', [ApiController::class, 'backups'])->name('essentials.api.backups');
                Route::get($base . '/schedules', [ApiController::class, 'schedules'])->name('essentials.api.schedules');
                Route::get($base . '/alerts', [ApiController::class, 'alerts'])->name('essentials.api.alerts');
                Route::get($base . '/me/servers', [ApiController::class, 'myServers'])->name('essentials.api.me.servers');
                Route::get($base . '/me/backups', [ApiController::class, 'myBackups'])->name('essentials.api.me.backups');
                Route::get($base . '/servers/{server}/players', [ApiController::class, 'players'])->name('essentials.api.players');
                Route::get($base . '/servers/{server}/status', [ApiController::class, 'status'])->name('essentials.api.status');
                Route::post($base . '/connect/claim', [ApiController::class, 'claim'])->name('essentials.api.connect.claim');
                Route::get($base . '/connect/{discord}', [ApiController::class, 'connection'])->name('essentials.api.connect.read');
                Route::get($base . '/connect/{discord}/servers', [ApiController::class, 'connectionServers'])->name('essentials.api.connect.servers');
                Route::delete($base . '/connect/{discord}', [ApiController::class, 'disconnect'])->name('essentials.api.connect.cut');
            });
        } catch (Throwable) {
            // Routes are cached; `php artisan optimize:clear` brings it back.
        }
    }

    private function registerPermissions(): void
    {
        /*
         * The three broad ones, and then two per feature.
         *
         * view and update still open everything, which is what keeps this from
         * being a breaking change: a role that could reach the plugin before
         * can still reach all of it. The per-feature permissions are the narrow
         * way in - somebody who should write announcements and touch nothing
         * else gets "notices" and no more.
         *
         * Two of them, because looking and changing are different grants. The
         * feature's own name goes on meaning both, exactly as it did, and
         * "view-<feature>" is the half that opens a page without letting
         * anything be saved on it. Adding the narrow one rather than replacing
         * the wide one is what keeps every role that already exists intact.
         */
        Role::registerCustomPermissions([
            Theme::PERMISSION_MODEL => array_merge(
                ['view', 'update', 'arrange'],
                Features::permissions(),
            ),
        ]);

        /*
         * The plugin's own logo on its own block of permissions.
         *
         * Pelican types this as string|BackedEnum and hands whatever it gets to
         * Filament, which resolves a string through Blade Icons - so a picture
         * can only get here as a registered icon name, never as an <img> the
         * way NavIcon hands one to the sidebar. registerIconSet() is what makes
         * this name resolve; without it the section would render no icon at all.
         */
        Role::registerCustomModelIcon(
            Theme::PERMISSION_MODEL,
            IconPacks::SHIPPED . '-logo',
        );
    }

    /**
     * The icons that ship with this plugin, as a Blade Icons set.
     *
     * They were readable only by this plugin's own code, which resolved
     * `essentials-*` by reading the file itself - enough for the CSS that paints
     * a sidebar row, and not enough for anywhere Filament wants an icon name.
     * Registering the directory makes them ordinary icon names everywhere in the
     * panel, which is what lets the role editor take the logo.
     *
     * It also settles something that was quietly broken. Settings::iconPack()
     * accepts a saved pack only if it is `custom` or a key of IconPacks::sets(),
     * and sets() lists what Blade Icons knows about - which never included this
     * one. So "Use the Essentials icons everywhere" set the pack, the form
     * posted it, and the validator dropped it on the floor. Now the set exists,
     * the name is a key, and the choice survives the save.
     *
     * Not fatal if it fails: an unregistered set costs the logo on one section
     * and the picker falls back to Tabler, which is a panel that draws.
     */
    private function registerIconSet(): void
    {
        try {
            app(IconFactory::class)->add(IconPacks::SHIPPED, [
                'path' => plugin_path(Theme::directory(), 'resources/icons'),
                'prefix' => IconPacks::SHIPPED,
            ]);
        } catch (Throwable) {
            // A set that will not register is an icon that does not draw, not a
            // panel that will not boot.
        }
    }

    /**
     * The compiled theme. Vite picks the file up through the glob over
     * plugins/<id>/resources/css in the panel's vite.config.js, so `yarn build`
     * is all that is needed.
     */
    private function stylesheet(): string
    {
        /*
         * Held for the request, like settings() below it.
         *
         * Blade::render() is not a string operation: it writes the template to
         * a file named by its hash under storage/framework/views, compiles it if
         * that file is not already there, and renders it. Once per request is
         * one file_exists and an include; the memo makes it once rather than
         * once per render hook that asks.
         */
        if (self::$stylesheet !== null) {
            return self::$stylesheet;
        }

        $asset = 'plugins/' . Theme::directory() . '/resources/css/theme.css';

        try {
            return self::$stylesheet = Blade::render("@vite(['{$asset}'])");
        } catch (Throwable) {
            // Assets have not been built yet - `yarn build` in the panel directory
            // fixes it. Never take the panel down over a stylesheet. Not
            // memoised: a build finishing mid-request is far-fetched, but an
            // empty string cached over a real answer is not worth the risk.
            return '';
        }
    }

    /**
     * The bar levelling script, and - only for someone who may edit the layout -
     * the page arranger with what it needs to start.
     */
    private function script(): string
    {
        $directory = Theme::directory();
        $assets = ["plugins/{$directory}/resources/js/bars.js"];
        $bootstrap = '';

        // Only where the box it drives can appear. The script is inert without
        // it, so this is about not shipping bytes to every page of the panel for
        // a feature that lives on four of them.
        if (Features::maySee(Features::SETTINGS_SEARCH)) {
            $assets[] = "plugins/{$directory}/resources/js/settings-search.js";
        }

        /*
         * The stars on the server cards. Its wording is handed over rather than
         * written into the script, so the one place strings live stays the one
         * place strings live.
         */
        if (Features::maySee(Features::FAVOURITES)) {
            $assets[] = "plugins/{$directory}/resources/js/favourites.js";

            $bootstrap .= '<script>window.__ldFav=' . json_encode([
                /*
                 * The list itself, in the first response.
                 *
                 * Handed over rather than fetched, because the stars are drawn
                 * as soon as the cards are and a request to find out what to
                 * draw would mean a list that appears unstarred for a moment
                 * on every single page load.
                 */
                'starred' => $this->attempt(fn (): array => Favourites::for(), []),
                'save' => url('/legend-theme/favourites'),
                'token' => csrf_token(),

                'off' => Theme::trans('settings.servers.favourite'),
                'on' => Theme::trans('settings.servers.favourited'),
                'tab' => Theme::trans('settings.servers.favourites_tab'),
                'empty' => Theme::trans('settings.servers.favourites_empty'),
                'failed' => Theme::trans('settings.servers.favourites_failed'),
            ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';</script>';
        }

        /*
         * The top bar's switcher.
         *
         * What is handed over is an address, a token and some words - not the
         * server list. Nothing is fetched until somebody opens it, so this
         * costs a few hundred bytes on a page nobody uses it on rather than a
         * query on every page of the panel.
         */
        if (Features::maySee(Features::QUICK)) {
            $assets[] = "plugins/{$directory}/resources/js/quick.js";

            $bootstrap .= '<script>window.__ldQuick=' . json_encode(
                $this->attempt(fn (): array => Quick::bootstrap(), []),
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            ) . ';</script>';
        }

        if (Theme::canArrange()) {
            $assets[] = "plugins/{$directory}/resources/js/arrange.js";

            $path = request()->path();
            $canShare = Theme::canArrangeForEveryone();

            /*
             * Appended, not assigned - and that one character was a bug.
             *
             * Three features put a line of configuration in here and this one
             * replaced the two above it instead of joining them. It only went
             * wrong for somebody who may rearrange pages, which is to say for
             * administrators and for nobody testing as an ordinary user, and
             * what it looked like from the outside was that starred servers
             * emptied themselves: window.__ldFav was never defined, the script
             * read no starred list, and the first click saved that empty list
             * back over the real one.
             */
            $bootstrap .= '<script>window.__ldArrange=' . json_encode([
                'canEdit' => true,
                // Whether the editor offers "for everyone" at all. Checked again
                // on the way in - this only decides what is drawn.
                'canShare' => $canShare,
                'url' => url('/legend-theme/layout'),
                'page' => Layouts::pageKey($path),
                // Each scope on its own, so switching between them shows what
                // that scope holds rather than the layers added together.
                'merged' => (object) Layouts::for($path),
                'shared' => (object) ($canShare ? Layouts::scoped($path, Layouts::SHARED) : []),
                /*
                 * The roles, and what each of them has arranged on this page.
                 *
                 * Sent with the page rather than fetched when the picker
                 * changes: it is the same shape as the shared one above, it
                 * saves an endpoint that would exist for nothing else, and a
                 * panel with a hundred roles is not a panel. Only for somebody
                 * who may set them - for anybody else this is two empty
                 * objects and no query.
                 */
                'roles' => (object) ($canShare ? Layouts::roleOptions() : []),
                'roleLayouts' => (object) ($canShare ? $this->attempt(
                    fn (): array => Layouts::roleLayouts($path),
                    [],
                ) : []),
            ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';</script>';
        }

        try {
            $list = implode("','", $assets);

            return $bootstrap . Blade::render("@vite(['{$list}'])");
        } catch (Throwable) {
            return '';
        }
    }

    /**
     * The panel's own settings block, and then - for anyone who has chosen a
     * style of their own - the same block built from theirs.
     *
     * Twice rather than once with the values swapped in, because a second block
     * after the first is the whole mechanism: everything in it wins by being
     * later, and a person who has chosen nothing gets exactly the page they got
     * before this existed. It costs a few kilobytes on the pages of the people
     * who asked for it.
     */
    private function settings(): string
    {
        /*
         * Built once per request.
         *
         * Render hooks re-fire inside Livewire responses - the lesson the blank
         * console cost a week - so this closure runs again on every interaction
         * with the page, not only on the page. Everything it reads is fixed for
         * the life of the request: the settings, who is asking, and the path.
         * Building it twice was already waste; building it twice over, once for
         * the panel and once for somebody's own style, is twice that.
         */
        if (self::$settings !== null) {
            return self::$settings;
        }

        /*
         * A full-page preview replaces the panel's own settings for this one
         * request, and nothing else about the request changes.
         *
         * Through Theme::using(), which is the mechanism a person's own style
         * already uses and is released in a finally - so a pending value cannot
         * be left standing where a form would read it back as the panel's and
         * save it there. Only the stylesheet is built from it; every other
         * reader in the request still sees what is stored.
         *
         * A person's own style is skipped while previewing. The question being
         * asked is what the panel looks like, and answering it with somebody's
         * personal override on top would answer a different one.
         */
        // Not wrapped in attempt(): that one returns a string and has no
        // fallback, and values() already answers null to everything it meets.
        $preview = FullPreview::values();

        if ($preview !== null) {
            $css = $this->attempt(
                fn (): string => Theme::using($preview, fn (): string => $this->settingsCss()),
            );

            /*
             * The arrangement with it, and uncached like the rest of this
             * branch. It moved out of settingsCss() when that became cacheable,
             * and without this line a full-page preview would show the panel
             * with every block back in its default order - which is a preview
             * answering a question nobody asked.
             */
            $css .= $this->attempt(fn (): string => Layouts::css(request()->path()));

            return self::$settings = '<style>' . $css . '</style>';
        }

        $panel = $this->cached('panel');

        /*
         * Between the two, and the order is the rule.
         *
         * A scheduled window beats the panel's own settings, because that is
         * what scheduling one means. A person's own style beats the window,
         * because somebody who has picked a look for themselves has already
         * answered the question the schedule is asking.
         *
         * Everything here is one stylesheet where later wins, so the order in
         * this concatenation is the whole precedence - there is no resolver and
         * nothing to keep in step with one.
         */
        /*
         * Each keyed on the preset it is built from, so the two of them cost
         * once per preset rather than once per reader: twenty people on the
         * same style share one entry.
         *
         * The presets are read out here rather than inside the closures, and
         * that is not tidiness. Each closure runs inside Theme::using(), which
         * swaps what config() answers for its length - so asking in there is
         * asking under the very values the answer is meant to select.
         */
        $windowPreset = $this->attempt(fn (): ?string => Windows::active(), null);
        $ownPreset = $this->attempt(fn (): ?string => UserTheme::choice(), null);
        $window = $this->attempt(fn (): string => Windows::css(
            fn (): string => $this->cached('window', $windowPreset),
        ));

        $own = $this->attempt(fn (): string => UserTheme::css(
            fn (): string => $this->cached('own', $ownPreset),
        ));

        /*
         * And the arrangement, live and last.
         *
         * It is the one part of the block that belongs to this reader and this
         * page rather than to the panel, so it can never go in a shared entry -
         * putting it there would serve one person's arrangement to everybody.
         * It is emitted last already, which is what makes pulling it out of the
         * cached prefix a split rather than a reorder.
         */
        $arrangement = $this->attempt(fn (): string => $this->arrangement());

        return self::$settings = '<style>' . $panel . $window . $own . $arrangement . '</style>';
    }

    /**
     * Settings that the stylesheet reads as custom properties, plus the opt-outs
     * for the effects that are toggled off.
     */
    /**
     * One block of the settings stylesheet, built once and kept.
     *
     * It was rebuilt on every page - fifteen classes, colour arithmetic, and a
     * couple of files off disk - and up to three times over on a page where
     * somebody has a style of their own and a timed window is open. Nothing was
     * kept between requests except the icon block, which is where the shape of
     * this came from.
     *
     * **What the key has to carry.** The stamp covers every setting and every
     * list the block reads; Support\Stamp says which writers move it. The
     * preset covers the two blocks that are the same composition with different
     * values. And two facts about the reader that change what comes out:
     *
     *   - Layout::css() asks whether this person chose their own navigation,
     *     because the theme sets a default and a person overrides it.
     *   - ServerControls::bareCss() asks whether this is the console opened as
     *     a window of its own, which is a query parameter.
     *
     * Both are booleans, so they add four variants to a key that would
     * otherwise have one - which is nothing beside rebuilding the block.
     *
     * Neither is pulled out into the live tail the way the arrangement is, and
     * that is deliberate: they sit in the middle of the composition, and Areas
     * is emitted last on purpose so a per-area override wins from everything
     * above it. Moving two rules past Areas to make the key simpler would be
     * changing which rule wins, invisibly, to save four cache entries.
     */
    private function cached(string $part, ?string $preset = null): string
    {
        try {
            return cache()->remember(
                Stamp::key($part, [
                    $preset,
                    Layout::userChoseNavigation(),
                    ServerControls::isBare(),
                ]),
                now()->addDay(),
                fn (): string => $this->settingsCss(),
            );
        } catch (Throwable $exception) {
            /*
             * A cache that cannot be written must not take the panel's styling
             * with it. Seen before on a panel where storage/framework/cache was
             * not writable by the web user: every write threw, and pages went
             * down with it.
             */
            report($exception);

            return $this->settingsCss();
        }
    }

    /**
     * This reader's arrangement of this page, built once and kept.
     *
     * The last of what was still read from disk on every page. Layouts::css()
     * reads up to four files - the shared arrangement, the role index, a role's
     * own, and the reader's - and unlike everything else in the block it cannot
     * go in a shared entry, because it belongs to one person.
     *
     * So the reader is in the key. The page is the folded one, so every
     * server's settings page shares an entry rather than each server having its
     * own, and the stamp is the arrangements' rather than the settings' - a
     * colour change should not throw arrangements away, and a dragged block
     * should not throw the panel's stylesheet away.
     *
     * The stars and a personal style stay live beside this, and that is a
     * measurement rather than an oversight: each is one file read, already held
     * for the request, and the stars are written on every click of a star. A
     * cache invalidated that often costs more than the read it saves.
     */
    private function arrangement(): string
    {
        $path = request()->path();

        try {
            $id = user()?->id;

            return cache()->remember(
                Stamp::arrangementKey(
                    is_numeric($id) ? (int) $id : null,
                    Layouts::pageKey($path),
                ),
                now()->addDay(),
                static fn (): string => Layouts::css($path),
            );
        } catch (Throwable $exception) {
            // A cache that will not answer must not cost the page its
            // arrangement, which is the one part of this that people move by
            // hand and would notice snapping back.
            report($exception);

            return Layouts::css($path);
        }
    }

    private function settingsCss(): string
    {
        /*
         * The appearance tokens live in Support\Preview now, and the panel is
         * one of its two callers.
         *
         * Not because the panel needed anything, but because the preview box
         * needs exactly these and must not have its own copy of them. A preview
         * built from a second set of rules is a second place the theme can be
         * wrong, and one that disagrees with the panel is worse than no preview
         * at all. Asking for them on `:root` is what this method always did.
         */
        $css = Preview::tokens();

        $css .= Background::css();
        $css .= Icons::css();
        $css .= Bars::css();

        // The shape of the panel: the rail, and the sidebar, topbar and card
        // styles. Before the per-area block, so an area can still override it.
        $css .= Layout::css();

        // How a server card is drawn, before the per-area block below.
        $css .= ServerList::css();
        $css .= ServerConsole::css();


        // The panel's lettering, and nothing at all when it has not been
        // changed - see Typography::css() for why that is the whole rule rather
        // than a custom property.
        $css .= Typography::css();

        // The terminal's own colours and behaviour. Emitted as custom
        // properties that the inlined runtime reads back, because xterm draws
        // to a canvas and a stylesheet cannot reach the glyphs.
        $css .= Terminal::css();

        // A console page opened as a window of its own, stripped to the
        // console. After the layout, since it undoes most of it.
        $css .= ServerControls::bareCss();

        // Which notice this is, so a browser can tell a new one from the one it
        // closed - read before the first paint, so nothing flashes.
        $css .= Features::enabled(Features::ANNOUNCEMENTS) ? Notice::css() : '';

        // The fetched favicons, painted over the icon Filament rendered for
        // each link. Stored data, so nothing here reaches out to a network.
        $css .= Features::enabled(Features::NAV_LINKS) ? NavLinks::css() : '';

        $css .= Features::enabled(Features::LOGIN) ? Login::css() : '';

        // Last, so a per-area override wins from every global setting above.
        $css .= Areas::css();

        /*
          * The arrangement is not here any more - settings() appends it after
          * every block, live.
          *
          * It is this reader's, on this page, and everything else in this
          * method is the panel's. A shared cache entry holding one person's
          * arrangement would draw it for everybody, which is the fault that
          * would have shipped had this been cached as it stood.
          */

        // The rules only, with no <style> around them: settings() wraps the
        // blocks it builds together in one.
        return $css;
    }

    /**
     * The login screen: its own picture, card width and card blur.
     */
}
