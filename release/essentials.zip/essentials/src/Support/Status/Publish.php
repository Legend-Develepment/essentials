<?php

namespace LegendDevelopment\Theme\Support\Status;

use App\Enums\ContainerStatus;
use App\Models\Server;
use Illuminate\Support\Facades\Cache;
use LegendDevelopment\Theme\Support\Features;
use LegendDevelopment\Theme\Support\Games\A2S;
use LegendDevelopment\Theme\Support\Games\Games;
use LegendDevelopment\Theme\Support\Minecraft\Minecraft;
use LegendDevelopment\Theme\Support\NodeHealth;
use LegendDevelopment\Theme\Support\Palette;
use LegendDevelopment\Theme\Support\Presets;
use LegendDevelopment\Theme\Support\Minecraft\Ping;
use LegendDevelopment\Theme\Support\Theme;
use LegendDevelopment\Theme\Support\UserTheme;
use Throwable;

/**
 * What the world is allowed to see.
 *
 * This is the first thing this plugin has ever served to somebody who is not
 * signed in, and that changes the standard rather than merely adding a page. On
 * every other page the question is "what does this person need"; here it is
 * "what would I be prepared to see on somebody else's forum", and the answer is
 * a name, whether it is up, and how many people are on it.
 *
 * Four rules, and none of them is optional:
 *
 *  1. **Opt in per server.** Nothing is public because a feature was switched
 *     on. The list starts empty and a server appears on it only because
 *     somebody ticked it.
 *  2. **A typed name, not the server's own.** A server called "mc-prod-3
 *     (Bryan's, do not touch)" is an internal note. What goes out is what an
 *     administrator wrote for the public, and when they wrote nothing, nothing
 *     goes out - the server is skipped rather than named by accident.
 *  3. **Built on a timer, served from a snapshot.** A status page that asked
 *     every node on every request is a way to have a busy forum thread take
 *     your panel down. What the browser gets is a file that was written
 *     earlier.
 *  4. **Fails closed.** A server the panel cannot reach reads as "unknown", not
 *     as "down". They are different facts and only one of them is safe to
 *     guess - and saying the wrong one in public is worse than saying nothing.
 */
class Publish
{
    /** Where a built snapshot lives; one per page. */
    private const KEY = 'legend-theme.status.snapshot';

    /**
     * How often a page rebuilds, and therefore how often it asks.
     *
     * Chosen per page. A clan page somebody watches during a restart wants ten
     * seconds; a page linked from a forum that nobody has open wants an hour,
     * and asking every node every minute for it would be work done for nobody.
     *
     * **Realtime is ten seconds, and the name is generous.** Nothing underneath
     * moves faster: Pelican caches a server's state for fifteen seconds, and
     * both game pings hold their answers for twenty. Asking every second would
     * be the same answer read repeatedly out of three caches, and the honest
     * floor is where the data actually changes rather than where a browser
     * could be made to ask.
     */
    public const EVERY = [
        'realtime' => 10,
        '30s' => 30,
        '1m' => 60,
        '5m' => 300,
        '10m' => 600,
        '30m' => 1800,
        '60m' => 3600,
    ];

    /** What a page is set to, when it has not said. */
    public const DEFAULT_EVERY = '1m';

    /**
     * The gap between two builds of one page, in seconds.
     *
     * Also the countdown the page shows, and the life of the lock that stops
     * forty visitors in one interval producing forty builds. One method, so
     * those three can never disagree - which they would, being the same number
     * written in three places.
     *
     * @param  array<string, mixed>  $own  the page's own settings, if it has any
     */
    public static function every(array $own = []): int
    {
        $key = (string) ($own['every'] ?? Theme::config('status_every', self::DEFAULT_EVERY));

        return self::EVERY[$key] ?? self::EVERY[self::DEFAULT_EVERY];
    }

    /**
     * How long a snapshot stands in the cache.
     *
     * Twice the interval, and never less than five minutes. It only has to
     * cover a rebuild that did not happen - the page asks again on the interval
     * and rebuilds a stale one itself - so this is a floor under how bad a
     * missed build can get rather than the mechanism.
     */
    private static function holds(int $every): int
    {
        return max(300, $every * 2);
    }

    /**
     * The choices, for a form.
     *
     * @return array<string, string>
     */
    public static function everyOptions(): array
    {
        return [
            'realtime' => Theme::trans('status.every_realtime'),
            '30s' => Theme::trans('status.every_30s'),
            '1m' => Theme::trans('status.every_1m'),
            '5m' => Theme::trans('status.every_5m'),
            '10m' => Theme::trans('status.every_10m'),
            '30m' => Theme::trans('status.every_30m'),
            '60m' => Theme::trans('status.every_60m'),
        ];
    }

    private const BUILDING = 'legend-theme.status.building';

    /**
     * How long the floor stands when nothing releases it.
     *
     * Not the page's interval, which is what it used to be: a build that takes
     * longer than the gap it is enforcing lets the next request start a second
     * one while the first is still walking sockets. This is a ceiling on a
     * build rather than a display setting, and it only ever matters when the
     * process holding it dies - an ordinary build gives it back in the finally
     * at the end of build().
     */
    private const BUILDING_FOR = 300;

    public static function enabled(): bool
    {
        try {
            return Features::enabled(Features::PUBLIC_STATUS) && self::published();
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * Whether anything at all has been put on the page.
     *
     * All three lists, and the reason that is worth its own method: this asked
     * only about the servers, so a panel with a machine and two monitors on it
     * and no servers reported that nothing was being served and answered 404 -
     * while the settings page showed the machine and the monitors sitting there
     * saved. Every one of the three draws its own section on the page, so any
     * one of them is a page worth serving.
     *
     * Monitors::rows() reads a file rather than a setting, which is why it goes
     * last: it is memoised per request, but the two cheap questions are asked
     * first and usually answer.
     */
    public static function published(): bool
    {
        return self::rows() !== []
            || self::nodeRows() !== []
            || Monitors::rows() !== [];
    }

    /**
     * The servers an administrator chose, and what they called them.
     *
     * Stored as `id:name` pairs joined by a pipe, the same shape the icon
     * overrides use - one setting, no table, and it survives a round trip
     * through .env.
     *
     * @return array<int, array{id: int, name: string}>
     */
    public static function rows(): array
    {
        return self::pairs((string) Theme::config('status_servers', ''));
    }

    /**
     * Pairs of id and name, joined by a pipe.
     *
     * One parser for the servers and the nodes, because they are the same
     * decision made twice - an id somebody picked and a name they typed.
     *
     * @return array<int, array{id: int, name: string}>
     */
    private static function pairs(string $stored): array
    {
        $out = [];

        foreach (explode('|', $stored) as $pair) {
            [$id, $name] = array_pad(explode(':', $pair, 2), 2, null);

            $id = (int) $id;
            $name = trim((string) $name);

            // No name, no row. Falling back to the server's own name is exactly
            // the accident rule two exists to prevent.
            if ($id <= 0 || $name === '') {
                continue;
            }

            $out[$id] = ['id' => $id, 'name' => mb_substr($name, 0, 60)];
        }

        return array_slice(array_values($out), 0, 50);
    }

    /**
     * The nodes an administrator chose, and what they called them.
     *
     * Same shape and same rule as the servers: a typed name, because a node is
     * usually called something like hetzner-fsn1-01 and that is a sentence
     * about where your machines are.
     *
     * Panel-wide only. A user's own page never shows nodes - which machine
     * their server sits on is the panel's business, not a tenant's.
     *
     * @return array<int, array{id: int, name: string}>
     */
    public static function nodeRows(): array
    {
        return self::pairs((string) Theme::config('status_nodes', ''));
    }

    /** A style value meaning "whatever the panel itself is set to". */
    public const FOLLOW = 'panel';

    /**
     * How a page looks.
     *
     * One place, so the panel's own page and somebody's resolve a style
     * identically - and so "follow the panel" means the same thing on both.
     *
     * One setting, not three.
     *
     * It began as a style, an accent override and a light/dark selector, and
     * that was two too many. A style already says what colour it is and whether
     * it is a light or a dark one - Paper is light, Ember is not - so an accent
     * box beside it is a way to contradict the thing you just chose, and a mode
     * selector beside it is a way to put white text on a white page. The first
     * person to use it set an accent and then reported that the style did not
     * work, which is exactly what those two controls were built to do to each
     * other.
     *
     * So the style brings everything: its colour, the surface every grey is
     * built from, how round the corners are, and - read off that surface rather
     * than asked separately - whether the page is light or dark.
     *
     * Everything here is sanitised rather than trusted. All of it is
     * interpolated into a stylesheet on a page served with no login in front of
     * it, and the choice is made by a user.
     *
     * @param  array<string, mixed>  $own  the page's own settings, if it has any
     * @return array{accent: string, surface: string, radius: string, mode: string}
     */
    public static function style(array $own = []): array
    {
        $style = (string) ($own['style'] ?? Theme::config('status_style', self::FOLLOW));

        /*
         * A preset if it names one, and the panel's own settings otherwise.
         *
         * Presets::values() answers with every field a preset fills in, and an
         * unknown name answers with nothing - so a style that was deleted after
         * a page chose it falls back to the panel rather than to a blank page.
         */
        $values = $style === self::FOLLOW || !Presets::exists($style)
            ? ['accent' => Theme::config('accent'), 'surface' => Theme::config('surface', ''), 'radius' => Theme::config('radius', 'normal')]
            : Presets::values($style);

        $surface = trim((string) ($values['surface'] ?? ''));

        return [
            'accent' => Palette::sanitize($values['accent'] ?? ''),
            /*
             * The one colour every grey on the page is built from.
             *
             * A preset may leave it empty, meaning "the theme's own near-black",
             * so there is a fallback here rather than a page of undefined
             * custom properties.
             */
            'surface' => Palette::sanitize($surface === '' ? '#16181d' : $surface),
            'radius' => in_array($values['radius'] ?? '', ['sharp', 'normal', 'round'], true)
                ? (string) $values['radius']
                : 'normal',
            'mode' => self::modeOf($surface === '' ? '#16181d' : $surface),
        ];
    }

    /**
     * Whether a surface is a light one.
     *
     * Asked of the colour rather than of a setting, because a style already
     * knows: Paper is a light theme and Midnight is not, and making somebody
     * say so again is making them able to get it wrong.
     *
     * Worked out through Palette::contrast(), which is already here and already
     * tested - whichever of black or white reads better on the surface is the
     * ink the page wants, and that is the same question as light or dark.
     */
    private static function modeOf(string $surface): string
    {
        try {
            return Palette::contrast($surface, '#000000') > Palette::contrast($surface, '#ffffff')
                ? 'light'
                : 'dark';
        } catch (Throwable) {
            return 'dark';
        }
    }

    /**
     * The styles a page may be set to.
     *
     * Two lists, and the difference is the same one the Appearance page already
     * makes: **which styles exist is the administrator's decision, which one you
     * use is yours.**
     *
     *  - An administrator gets every style the panel has, because they can
     *    already set any of them as the panel's own look. Offering fewer here
     *    would be a restriction that exists nowhere else they go.
     *  - A user gets the list an administrator chose to offer - the same one
     *    they pick from for their own view of the panel, under Appearance. A
     *    style nobody was offered is not one to hand out on a public page
     *    through a different door.
     *
     * Both always include following the panel, which is the default and the
     * answer for anybody who does not want to think about it.
     *
     * @return array<string, string>
     */
    public static function styles(bool $forUser = false): array
    {
        $out = [self::FOLLOW => Theme::trans('status.style_panel')];

        try {
            $names = $forUser ? UserTheme::allowed() : Presets::names();

            foreach ($names as $name) {
                $out[$name] = Presets::label($name);
            }
        } catch (Throwable) {
            // No styles is just the one option, which still works.
        }

        return $out;
    }

    /**
     * @param  array<int, array{id: mixed, name: mixed}>  $rows
     */
    public static function toStorage(array $rows): string
    {
        $pairs = [];

        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $id = (int) ($row['id'] ?? 0);
            $name = is_string($row['name'] ?? null) ? trim($row['name']) : '';

            // The two characters that would break the format back apart, and
            // control characters, which have no business in a public label.
            $name = str_replace(['|', ':'], ' ', $name);
            $name = trim(preg_replace('/[[:cntrl:]]+/u', ' ', $name) ?? '');
            $name = trim(preg_replace('/\s+/u', ' ', $name) ?? '');

            if ($id <= 0 || $name === '') {
                continue;
            }

            $pairs[$id] = $id . ':' . mb_substr($name, 0, 60);
        }

        return implode('|', array_slice(array_values($pairs), 0, 50));
    }

    /**
     * The snapshot, built if there is not one and it is allowed.
     *
     * @return array{at: int, servers: array<int, array{name: string, state: string, online: ?int, max: ?int}>}
     */
    public static function read(?int $userId = null): array
    {
        try {
            $held = Cache::get(self::key($userId));

            /*
             * Fresh enough, or rebuilt - not merely present.
             *
             * This used to hand back whatever was cached until it expired,
             * which was fifteen minutes and is now five. So the page counted
             * down from sixty, asked again on the minute, and got the same
             * snapshot back four times running. It looked broken because it
             * was: the countdown was promising something the reader could not
             * deliver.
             *
             * The scheduler rebuilding every minute was supposed to cover that,
             * and covers it only on a panel whose cron actually runs Laravel's
             * scheduler. That is not something a status page should depend on -
             * so a snapshot older than the interval is rebuilt when somebody
             * asks for it, and the schedule becomes what saves the first
             * visitor of the minute from paying for the build rather than what
             * makes the page work at all.
             *
             * The lock inside build() is what makes this safe: forty visitors
             * in the same minute produce one build and thirty-nine reads.
             */
            if (is_array($held) && isset($held['servers'])) {
                $age = time() - (int) ($held['at'] ?? 0);

                if ($age < (int) ($held['every'] ?? self::every())) {
                    return $held;
                }
            }
        } catch (Throwable) {
            // An unreadable cache builds below, which is slow and correct.
        }

        return self::build($userId);
    }

    /**
     * Drop a snapshot, so the next read builds a fresh one.
     *
     * Called whenever the inputs change rather than waiting for the snapshot to
     * age out. A monitor removed in the settings and still on the page for four
     * minutes is indistinguishable from a page that does not work - which is
     * exactly how it was reported.
     *
     * Null forgets the panel's own page; an id forgets one person's.
     */
    public static function forget(?int $userId = null): void
    {
        try {
            Cache::forget(self::key($userId));

            /*
             * And the lock, which is the half that is easy to miss.
             *
             * build() answers with whatever is cached while a build is in
             * flight, and forgetting the snapshot without the lock leaves it
             * answering with nothing - a blank page for up to a minute after
             * saving, and a 404 on a user page, because an empty list is how
             * that page says there is nothing to show.
             *
             * A settings change is exactly the moment an immediate rebuild is
             * wanted, so the floor is lifted for it rather than waited out.
             */
            Cache::forget(self::BUILDING . ($userId === null ? '' : '.user.' . $userId));
        } catch (Throwable) {
            // The snapshot ages out on its own within the minute now, so a
            // cache that will not answer costs freshness rather than
            // correctness.
        }
    }

    /**
     * Seconds until this snapshot is rebuilt.
     *
     * Sent to the page so the countdown never compares a server timestamp with
     * a browser clock. Those disagree - by seconds on a good day and by hours on
     * a phone somebody has set by hand - and a countdown built on the difference
     * either never fires or fires every second for ever.
     */
    public static function due(int $at, int $every): int
    {
        return max(0, $every - max(0, time() - $at));
    }

    /**
     * One cache entry per page.
     *
     * The panel's own and each person's are different lists reaching different
     * daemons, and sharing a key would mean the first visitor of the minute
     * deciding what everybody else's page says.
     */
    private static function key(?int $userId): string
    {
        return self::KEY . ($userId === null ? '' : '.user.' . $userId);
    }

    /**
     * Ask every chosen server how it is, and write the answer down.
     *
     * Behind a lock and a floor: this reaches every node it touches, and the
     * schedule is not the only thing that can call it - a page nobody has
     * scheduled builds on its first visit, and forty visitors in the same
     * minute must produce one build rather than forty.
     *
     * @return array{at: int, servers: array<int, array{name: string, state: string, online: ?int, max: ?int}>}
     */
    public static function build(?int $userId = null): array
    {
        $empty = ['at' => time(), 'servers' => [], 'nodes' => [], 'monitors' => [], 'title' => '', 'note' => ''];

        if (!Features::enabled(Features::PUBLIC_STATUS)) {
            return $empty;
        }

        $key = self::key($userId);
        $lock = self::BUILDING . ($userId === null ? '' : '.user.' . $userId);

        // The page's own interval, read before the lock so the lock lasts
        // exactly as long as the gap it is enforcing.
        $every = $userId === null
            ? self::every()
            : self::every(['every' => Pages::of($userId)['every']]);

        /*
         * Taken, not looked at.
         *
         * This read the lock and then wrote it, which is a check-then-act with
         * a gap in the middle - and the one route that reaches this needs no
         * account at all. Two strangers asking in the same instant both saw no
         * lock and both started a build; sixty of them, which is what the
         * route's own throttle allows from one address, started sixty. Each
         * build walks up to fifty servers and twenty monitors with outbound
         * sockets on them, in the request, holding a worker.
         *
         * add() is the atomic form: it writes only if nothing is there and says
         * which happened. Nothing else about the floor changes.
         */
        $mine = false;

        try {
            $mine = Cache::add($lock, true, self::BUILDING_FOR);

            if (!$mine) {
                // Somebody else is building it. Whatever is stored is the
                // answer, even if that is nothing yet: a second build would not
                // be faster and this one is not free.
                $held = Cache::get($key);

                return is_array($held) && isset($held['servers']) ? $held : $empty;
            }
        } catch (Throwable) {
            // No cache means no floor, and a page that still works. The panel
            // is in a worse state than this page.
        }

        try {
            $snapshot = $userId === null ? self::panelPage() : self::userPage($userId);
            $snapshot['every'] = $every;

            try {
                Cache::put($key, $snapshot, self::holds($every));
            } catch (Throwable) {
                // Built and served without being kept, which is slow rather
                // than broken.
            }

            return $snapshot;
        } finally {
            /*
             * Let go the moment it is built, rather than at the end of a TTL.
             *
             * The lock used to last exactly as long as the page's own interval,
             * which is a minute by default - so the scheduled rebuild, which
             * runs every minute, met its own previous lock about as often as it
             * did not, and skipped. That is what left the building on the
             * anonymous request path in the first place. Released here, the
             * TTL above is only what covers a process that dies mid-build.
             */
            if ($mine) {
                try {
                    Cache::forget($lock);
                } catch (Throwable) {
                    // It expires on its own. The floor is a floor, not a
                    // promise.
                }
            }
        }
    }

    /**
     * The panel's own page: chosen servers, chosen nodes, and the monitors.
     *
     * @return array{at: int, servers: array<int, mixed>, nodes: array<int, mixed>, monitors: array<int, mixed>, title: string, note: string}
     */
    private static function panelPage(): array
    {
        $servers = [];

        foreach (self::rows() as $row) {
            $servers[] = self::one($row['id'], $row['name']);
        }

        return [
            'at' => time(),
            'servers' => $servers,
            'nodes' => self::nodes(),
            'monitors' => Monitors::check(),
            'title' => trim((string) Theme::config('status_title', '')),
            'note' => trim((string) Theme::config('status_note', '')),
            'style' => self::style(),
        ];
    }

    /**
     * Somebody's own page: their servers, and nothing else.
     *
     * No nodes and no monitors, and neither is an oversight. See Status\Pages
     * for why each is the administrator's alone.
     *
     * @return array{at: int, servers: array<int, mixed>, nodes: array<int, mixed>, monitors: array<int, mixed>, title: string, note: string}
     */
    private static function userPage(int $userId): array
    {
        $page = Pages::of($userId);
        $servers = [];

        foreach ($page['servers'] as $row) {
            $servers[] = self::one($row['id'], $row['name']);
        }

        return [
            'at' => time(),
            'servers' => $servers,
            'nodes' => [],
            'monitors' => [],
            'title' => $page['title'],
            'note' => $page['note'],
            'style' => self::style(['style' => $page['style']]),
        ];
    }

    /**
     * The chosen nodes, reduced to what may be said in public.
     *
     * Up or down and nothing else. Not the load, not how full the disk is, not
     * how many servers are on it - a visitor asking whether they can play does
     * not need a capacity report on somebody's hardware, and publishing one is
     * a map of where the pressure is.
     *
     * @return array<int, array{name: string, state: string}>
     */
    private static function nodes(): array
    {
        $wanted = self::nodeRows();

        if ($wanted === []) {
            return [];
        }

        $named = [];

        foreach ($wanted as $row) {
            $named[$row['id']] = $row['name'];
        }

        $out = [];

        try {
            // The named ones, however many were named: the default ceiling is
            // the dashboard's and would drop a node somebody put on the page.
            foreach (NodeHealth::nodes(array_keys($named), false, NodeHealth::MOST) as $node) {
                $id = (int) ($node['id'] ?? 0);

                if (!isset($named[$id])) {
                    continue;
                }

                $out[] = [
                    'name' => $named[$id],
                    // Maintenance reads as unknown rather than down: it is
                    // deliberate, it is temporary, and "offline" would have
                    // people asking what happened.
                    'state' => match (true) {
                        (bool) ($node['maintenance'] ?? false) => 'unknown',
                        (bool) ($node['reachable'] ?? false) => 'up',
                        default => 'down',
                    },
                ];
            }
        } catch (Throwable) {
            return [];
        }

        return $out;
    }

    /**
     * One server, reduced to what may be said about it in public.
     *
     * @return array{name: string, state: string, online: ?int, max: ?int}
     */
    private static function one(int $id, string $name): array
    {
        $row = ['name' => $name, 'state' => 'unknown', 'online' => null, 'max' => null];

        try {
            $server = Server::query()->find($id);

            if ($server === null) {
                // Deleted since it was chosen. Named, because a row that
                // vanished silently is a page that quietly stops mentioning a
                // server people are asking about.
                return $row;
            }

            $state = $server->retrieveStatus();

            /*
             * Three states out of eleven.
             *
             * The public does not need to know the difference between exited,
             * dead and removing - they need to know whether they can play. And
             * Missing is what Pelican answers for a node in maintenance as well
             * as for a container it cannot find, which is precisely why it maps
             * to unknown rather than to down.
             */
            $row['state'] = match ($state) {
                ContainerStatus::Running => 'up',
                ContainerStatus::Starting, ContainerStatus::Restarting => 'starting',
                ContainerStatus::Offline, ContainerStatus::Exited, ContainerStatus::Dead,
                ContainerStatus::Stopping, ContainerStatus::Paused => 'down',
                default => 'unknown',
            };

            /*
             * Player counts, only where they are already being read.
             *
             * Both protocols are off unless an administrator switched them on,
             * and both open a connection from the panel to a game port. This
             * page does not switch either on for them - it uses whichever
             * answer exists and says nothing where there is none.
             *
             * Minecraft first because it is the older half and the more common
             * one on this panel; the Valve query second, for Rust, ARK, Valheim
             * and everything else that speaks it. A server cannot sensibly be
             * both, and if an administrator has ticked its egg in both lists
             * the first answer wins rather than the second overwriting it.
             */
            if ($row['state'] === 'up') {
                $live = Minecraft::detect($server) ? Ping::status($server) : null;

                if (!is_array($live) && Games::speaks($server)) {
                    $live = A2S::status($server);
                }

                if (is_array($live)) {
                    $row['online'] = (int) ($live['online'] ?? 0);
                    $row['max'] = (int) ($live['max'] ?? 0);
                }
            }
        } catch (Throwable) {
            // Unknown, which is what the row already says.
        }

        return $row;
    }
}
