<?php

namespace LegendDevelopment\Theme;

use App\Contracts\Plugins\HasPluginSettings;
use App\Filament\App\Resources\Servers\ServerResource;
use Exception;
use Filament\Actions\Action;
use Filament\Contracts\Plugin;
use Filament\Facades\Filament;
use Filament\Panel;
use LegendDevelopment\Theme\Filament\Admin\Pages\AdvancedSettings;
use LegendDevelopment\Theme\Filament\Admin\Pages\DuplicateServer;
use LegendDevelopment\Theme\Filament\Admin\Pages\EggArtwork;
use LegendDevelopment\Theme\Filament\Admin\Pages\GameSettings;
use LegendDevelopment\Theme\Filament\Admin\Pages\ServerAccess;
use LegendDevelopment\Theme\Filament\Admin\Pages\MinecraftSettings;
use LegendDevelopment\Theme\Filament\App\Pages\Appearance;
use LegendDevelopment\Theme\Filament\App\Pages\ApiAccess;
use LegendDevelopment\Theme\Filament\App\Pages\Basket;
use LegendDevelopment\Theme\Filament\App\Pages\Billing;
use LegendDevelopment\Theme\Filament\App\Pages\Checkout;
use LegendDevelopment\Theme\Filament\Profile\Profile;
use LegendDevelopment\Theme\Filament\App\Pages\MyServers;
use LegendDevelopment\Theme\Filament\App\Pages\MyStatus;
use LegendDevelopment\Theme\Filament\App\Pages\MyTickets;
use LegendDevelopment\Theme\Filament\App\Pages\Pay;
use LegendDevelopment\Theme\Filament\App\Pages\Service;
use LegendDevelopment\Theme\Filament\App\Pages\Services;
use LegendDevelopment\Theme\Filament\App\Pages\Store;
use LegendDevelopment\Theme\Filament\Pages\Favourites;
use LegendDevelopment\Theme\Filament\Admin\Pages\Alerts;
use LegendDevelopment\Theme\Filament\Admin\Pages\Announcements;
use LegendDevelopment\Theme\Filament\Admin\Pages\ApiKeys;
use LegendDevelopment\Theme\Filament\Admin\Pages\Backups;
use LegendDevelopment\Theme\Filament\Admin\Pages\FileSettings;
use LegendDevelopment\Theme\Filament\Admin\Pages\LanguageSettings;
use LegendDevelopment\Theme\Filament\Admin\Pages\ShopAddons;
use LegendDevelopment\Theme\Filament\Admin\Pages\ShopCoupons;
use LegendDevelopment\Theme\Filament\Admin\Pages\ShopCustomers;
use LegendDevelopment\Theme\Filament\Admin\Pages\ShopInvoices;
use LegendDevelopment\Theme\Filament\Admin\Pages\ShopOrders;
use LegendDevelopment\Theme\Filament\Admin\Pages\ShopOverview;
use LegendDevelopment\Theme\Filament\Admin\Pages\ShopPackages;
use LegendDevelopment\Theme\Filament\Admin\Pages\ShopPayments;
use LegendDevelopment\Theme\Filament\Admin\Pages\ShopSettings;
use LegendDevelopment\Theme\Filament\Admin\Pages\SupportTickets;
use LegendDevelopment\Theme\Filament\Auth\Register;
use LegendDevelopment\Theme\Http\Middleware\ShopFirst;
use LegendDevelopment\Theme\Http\PanelLanguage;
use LegendDevelopment\Theme\Filament\Admin\Pages\LoginScreen;
use LegendDevelopment\Theme\Filament\Admin\Pages\Look;
use LegendDevelopment\Theme\Filament\Admin\Pages\NavigationLinks;
use LegendDevelopment\Theme\Filament\Admin\Pages\Capacity;
use LegendDevelopment\Theme\Filament\Admin\Pages\PanelActivity;
use LegendDevelopment\Theme\Filament\Admin\Pages\PanelSchedules;
use LegendDevelopment\Theme\Filament\Admin\Pages\PanelPages;
use LegendDevelopment\Theme\Filament\Admin\Pages\PublicStatus;
use LegendDevelopment\Theme\Filament\Admin\Pages\SystemStatus;
use LegendDevelopment\Theme\Filament\Admin\Pages\ModuleSettings;
use LegendDevelopment\Theme\Filament\Admin\Pages\ThemeSettings;
use LegendDevelopment\Theme\Filament\Admin\Widgets\ThemeStatus;
use LegendDevelopment\Theme\Filament\Server\Pages\ArkConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\GamePlayers;
use LegendDevelopment\Theme\Filament\Server\Pages\MinecraftConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\Modpacks;
use LegendDevelopment\Theme\Filament\Server\Pages\Players;
use LegendDevelopment\Theme\Filament\Server\Pages\Resources;
use LegendDevelopment\Theme\Filament\Server\Pages\DontStarveConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\EnshroudedConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\FactorioConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\SatisfactoryConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\TerrariaConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\VRisingConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\OnsetConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\CraftopiaConfig;
use LegendDevelopment\Theme\Filament\Server\Pages\ValheimLists;
use LegendDevelopment\Theme\Filament\Server\Pages\PalworldSettings;
use LegendDevelopment\Theme\Support\Access\Sync;
use LegendDevelopment\Theme\Support\Features;
use LegendDevelopment\Theme\Support\Money;
use LegendDevelopment\Theme\Support\Layout;
use LegendDevelopment\Theme\Support\Mode;
use LegendDevelopment\Theme\Support\NavLinks;
use LegendDevelopment\Theme\Support\Palette;
use LegendDevelopment\Theme\Support\Quick;
use LegendDevelopment\Theme\Support\Presets;
use LegendDevelopment\Theme\Support\Registration;
use LegendDevelopment\Theme\Support\Settings;
use LegendDevelopment\Theme\Support\Standalone;
use LegendDevelopment\Theme\Support\Status\Pages as StatusPages;
use LegendDevelopment\Theme\Support\Shop\Credits;
use LegendDevelopment\Theme\Support\Shop\Packages;
use LegendDevelopment\Theme\Support\Theme;
use LegendDevelopment\Theme\Support\UserTheme;
use RuntimeException;
use Throwable;

class ThemePlugin implements HasPluginSettings, Plugin
{
    /**
     * Run one of the two entry points so a mistake in it cannot take the panel.
     *
     * Pelican wraps a plugin in `catch (Exception)`. An Error is a Throwable
     * and not an Exception, so a null dereference or a type error in here goes
     * straight past that guard and out of the panel provider - and a plugin
     * provider that throws during boot takes every page of the panel with it,
     * the console, and every artisan command, which includes the queue worker.
     *
     * That is not a hypothetical. One line asked a panel for another panel's
     * address while the panels were still being built, got null, and the
     * result was three hours of a dead panel and a queue worker that systemd
     * restarted sixty-seven times before giving up - and nothing on the screen
     * to say which plugin, because there was no screen.
     *
     * So an Error is turned into an Exception here, which is the one shape
     * Pelican knows what to do with: it marks this plugin errored, writes the
     * message where an administrator can read it, and leaves the rest of the
     * panel alone. The trace still reaches the log by way of report().
     *
     * This is a net, not a licence. Nothing here should throw, the gates exist
     * to keep it that way, and a plugin that quietly does nothing is its own
     * kind of bad afternoon - see the id mismatch in the README. But the choice
     * between one plugin switching itself off and a panel nobody can sign in to
     * is not a close one.
     */
    private function guarded(callable $work): void
    {
        try {
            $work();
        } catch (Exception $exception) {
            // Already the shape Pelican catches. Left exactly as it is, so its
            // message and its type reach the plugin list unchanged.
            throw $exception;
        } catch (Throwable $error) {
            report($error);

            throw new RuntimeException($error->getMessage(), 0, $error);
        }
    }

    public function getId(): string
    {
        return Theme::id();
    }

    public static function supportsStandalone(string $id): bool
    {
        // One list, in Standalone, rather than two that have to agree.
        return Standalone::knows($id);
    }

    public function register(Panel $panel): void
    {
        $this->guarded(fn () => $this->build($panel));
    }

    /**
     * Everything register() used to do, with a net under it.
     *
     * Split out rather than wrapped in place so the guard is one line at the
     * top of the file instead of an indent on four hundred.
     */
    private function build(Panel $panel): void
    {
        /*
         * After Pelican's own LanguageMiddleware, which is what appending to
         * the panel's list gets: that one is already in it, and a plugin's
         * middleware goes on the end. Registered on every panel rather than
         * one, because a reader's language is not a property of which panel
         * they are looking at.
         */
        $panel->middleware([PanelLanguage::class]);

        /*
         * And the one that lets a stranger see the shop.
         *
         * Here rather than on the web group, which is where it was and where it
         * did nothing: a Filament panel does not use that group. Its routes
         * carry an explicit list of middleware classes, so pushing onto web
         * reached every page of the panel except the panel. Appending to the
         * panel's own list puts this in front of Filament's Authenticate, which
         * is the whole point - it has to answer before the redirect to the
         * login is decided.
         *
         * On the app panel alone. The admin panel's front door should ask for a
         * sign-in, because there is nothing behind it for somebody who has not.
         */
        if ($panel->getId() === 'app') {
            $panel->middleware([ShopFirst::class]);
        }

        /*
         * Signing up, on the client panel and nowhere else.
         *
         * The admin panel has nothing behind it for somebody with no account
         * and the server panel is reached through a server, so the only front
         * door where a register link means anything is this one.
         *
         * **Registered only while it is open.** A page that exists and refuses
         * is still a page: the route answers, the link is drawable, and the
         * only thing between a stranger and the form is a check somebody has to
         * have remembered to write. Not registering it means the address is a
         * 404 like any other, which is the honest answer when the door is shut.
         *
         * Registration::open() is a plain setting rather than a Features
         * constant, and config/essentials.php says why: a feature arrives
         * switched on after an update, and a public door must not.
         */
        if ($panel->getId() === 'app' && Registration::open()) {
            $panel->registration(Register::class);
        }

        // The Theme page is registered even with the theme switched off, so it
        // can be switched back on.
        if ($panel->getId() === 'admin') {
            $panel->pages([
                ThemeSettings::class,
                // Registered beside it and never behind a feature of its
                // own, for the same reason: this is the page that
                // switches the others, so it may not be switchable off.
                ModuleSettings::class,
            ]);

            /*
             * And the rest, each only while the feature it settles is on.
             *
             * The same rule the shop pages below already follow, applied to the
             * pages that were exempt from it. canAccess() hides them from
             * whoever may not see them either way, so this is not about
             * permission: a page that is never registered is one fewer route,
             * one fewer class loaded, and one fewer thing for Filament to build
             * navigation for, on a panel that did not ask for it.
             *
             * Measured on a live panel with all fifty-three features off: these
             * twenty-one registered themselves anyway, and cost 37.8 KB of
             * markup on every admin page plus the memory to load them. The two
             * above stay whatever happens, because switching everything off has
             * to leave the page that switches it back on.
             */
            foreach ([
                Look::class => Features::LOOK,
                PanelPages::class => Features::PAGES,
                AdvancedSettings::class => Features::ADVANCED,
                Announcements::class => Features::ANNOUNCEMENTS,
                NavigationLinks::class => Features::NAV_LINKS,
                LoginScreen::class => Features::LOGIN,
                SystemStatus::class => Features::SYSTEM_STATUS,
                DuplicateServer::class => Features::DUPLICATE,
                MinecraftSettings::class => Features::MINECRAFT,
                GameSettings::class => Features::GAMES,
                ServerAccess::class => Features::ACCESS,
                PanelActivity::class => Features::ACTIVITY,
                PanelSchedules::class => Features::SCHEDULES,
                Capacity::class => Features::CAPACITY,
                LanguageSettings::class => Features::LANGUAGES,
                FileSettings::class => Features::FILES,
                EggArtwork::class => Features::ARTWORK,
                Alerts::class => Features::ALERTS,
                Backups::class => Features::BACKUPS,
                PublicStatus::class => Features::PUBLIC_STATUS,
                ApiKeys::class => Features::API,
            ] as $page => $feature) {
                if (Features::enabled($feature)) {
                    $panel->pages([$page]);
                }
            }

            /*
             * The shop, under a group of its own. Each page is registered
             * only while its feature is on - canAccess() would hide it either
             * way, but a page that is never registered is one fewer route on
             * a panel that did not ask for a shop.
             */
            if (Features::enabled(Features::PACKAGES)) {
                $panel->pages([ShopPackages::class]);
            }

            if (Features::enabled(Features::ORDERS)) {
                $panel->pages([ShopOrders::class]);
            }

            if (Features::enabled(Features::INVOICES)) {
                $panel->pages([ShopInvoices::class]);
            }

            if (Features::enabled(Features::PAYMENTS)) {
                $panel->pages([ShopPayments::class]);
            }

            if (Features::enabled(Features::ADDONS)) {
                $panel->pages([ShopAddons::class]);
            }

            if (Features::enabled(Features::COUPONS)) {
                $panel->pages([ShopCoupons::class]);
            }

            if (Features::enabled(Features::CUSTOMERS)) {
                $panel->pages([ShopCustomers::class]);
            }

            if (Features::enabled(Features::OVERVIEW)) {
                $panel->pages([ShopOverview::class]);
            }

            if (Features::enabled(Features::SHOP)) {
                $panel->pages([ShopSettings::class]);
            }

            /*
             * The support desk, outside the shop's own block on purpose: a
             * panel can want somewhere for people to ask questions without
             * selling anything, so this is not behind the shop switch.
             */
            if (Features::enabled(Features::TICKETS)) {
                $panel->pages([SupportTickets::class]);
            }

            /*
             * One block on the dashboard, holding both halves: the version line
             * - because "is there an update" is a question you have before you
             * go looking for the page that answers it - and the machines.
             *
             * Which halves it draws is decided inside the widget rather than
             * here, because either one alone is not worth a card of its own and
             * two cards saying the same plugin's name was one too many.
             */
            $panel->widgets([ThemeStatus::class]);
        }

        /*
         * The one page this plugin puts inside a server rather than in the
         * admin area, and the one that is about a game rather than about the
         * panel. It hides itself on any server that is not Palworld, and the
         * Features list switches it off everywhere.
         */
        if ($panel->getId() === 'server' && Features::enabled(Features::PALWORLD)) {
            $panel->pages([PalworldSettings::class]);
        }

        /*
         * The same shape for Minecraft: a page inside a server, hidden on every
         * server whose egg an administrator has not said is Minecraft.
         *
         * Registered whenever the feature is on, and canAccess() does the rest -
         * a page with no eggs ticked simply never appears, which is the same
         * answer as not registering it and one fewer thing that has to be right
         * at boot.
         */
        if ($panel->getId() === 'server' && Features::enabled(Features::MINECRAFT)) {
            $panel->pages([MinecraftConfig::class, Modpacks::class, Players::class, Resources::class]);
        }

        /*
         * Who is on a server, for the games that answer Valve's query.
         *
         * One page rather than one per game: Rust, ARK, Valheim and the rest
         * answer the same packet, so four pages would differ in nothing but the
         * word at the top. canAccess() hides it on every server whose egg an
         * administrator has not ticked, which is the same shape the Minecraft
         * pages use.
         */
        if ($panel->getId() === 'server' && Features::enabled(Features::GAME_PLAYERS)) {
            $panel->pages([GamePlayers::class]);
        }

        /*
         * The two games that keep a file rather than a set of start-up
         * variables: ARK's GameUserSettings.ini, and Valheim's three name
         * lists. Neither gets a settings form beyond that, and that is a
         * finding rather than a gap - everything else about both is a start-up
         * variable, and Pelican's Startup page already edits those.
         *
         * Registered together on one switch, and canAccess() does the rest: a
         * game with no eggs ticked never appears, which is the same answer as
         * not registering it and one fewer thing that has to be right at boot.
         */
        if ($panel->getId() === 'server' && Features::enabled(Features::GAMES)) {
            $panel->pages([
                ArkConfig::class,
                DontStarveConfig::class,
                EnshroudedConfig::class,
                FactorioConfig::class,
                SatisfactoryConfig::class,
                TerrariaConfig::class,
                VRisingConfig::class,
                OnsetConfig::class,
                CraftopiaConfig::class,
                ValheimLists::class,
            ]);
        }

        /*
         * Where somebody picks the panel's look for themselves. In the client
         * panel because that is the one everybody reaches, and only when an
         * administrator has offered something to pick from.
         */
        if ($panel->getId() === 'app' && UserTheme::enabled()) {
            $panel->pages([Appearance::class]);
        }

        /*
         * A status page of somebody's own.
         *
         * In the client panel because it belongs to whoever owns the servers,
         * and registered only when an administrator has allowed user pages at
         * all - canAccess() would hide it either way, but a page that is not
         * registered is one fewer route on a panel that does not want the
         * feature.
         */
        if ($panel->getId() === 'app' && StatusPages::enabled()) {
            $panel->pages([MyStatus::class]);
        }

        /*
         * Asking for a key of your own.
         *
         * Registered only while the API is switched on, like the route it is
         * about. canAccess() would hide it either way; a page that is never
         * registered is one fewer thing on a panel that did not ask for any of
         * this.
         */
        if ($panel->getId() === 'app' && Features::enabled(Features::API)) {
            $panel->pages([ApiAccess::class]);
        }

        /*
         * The shop, the checkout and somebody's own billing.
         *
         * All three or none: a store with no checkout is a dead end, and a
         * billing page with no way to have bought anything is an empty list.
         * The checkout keeps itself out of the sidebar - it is reached from a
         * card, and a navigation entry for it would be a link to a page that
         * asks which package you meant.
         *
         * Registered only while the shop is on, like every other feature here.
         */
        if ($panel->getId() === 'app' && Features::enabled(Features::SHOP)) {
            /*
             * The shop as the first thing somebody sees.
             *
             * Two halves, and neither works without the other. Pelican's own
             * ServerResource::embedServerList() moves the server list off the
             * root slug and puts it into the navigation; Store::asLanding()
             * moves the shop onto it. Doing one without the other would either
             * lose the server list or collide two pages at the same address.
             *
             * Wrapped, because embedServerList belongs to Pelican rather than
             * to this plugin: a panel where it has been renamed gets its
             * ordinary landing page rather than a fatal on every request.
             *
             * The customer's own things are reachable either way - the header
             * of this page carries them, and so does the account menu below,
             * which is the same answer this plugin already gives for the other
             * client pages: the client panel has no sidebar to put them in.
             */
            if ((bool) Theme::config('shop_landing', false)) {
                try {
                    ServerResource::embedServerList(true);
                    Store::asLanding(true);
                } catch (Throwable) {
                    Store::asLanding(false);
                }
            }

            $panel->pages([
                Store::class,
                Checkout::class,
                Basket::class,
                Pay::class,
                Services::class,
                // Reached from a service rather than from the sidebar,
                // like Pay is reached from an invoice.
                Service::class,
                Billing::class,
            ]);
        }

        /*
         * And in the account menu, on both panels a customer sits in.
         *
         * The same reasoning as the Appearance and My status rows above: the
         * client panel's sidebar is not the sidebar somebody sees while they
         * are inside a server, which is where people actually spend their
         * time. "Account" is where somebody looks for a thing that belongs to
         * them, and a service and an invoice are exactly that.
         */
        if (in_array($panel->getId(), ['app', 'server'], true) && Features::enabled(Features::SHOP)) {
            $panel->userMenuItems([
                Action::make('ld-services')
                    ->label(fn (): string => Theme::trans('shop.services_nav_label'))
                    ->icon('tabler-server-2')
                    /*
                     * Inside the closure, like every other row in this file.
                     *
                     * register() runs while the panel it is registering is
                     * being built, and Filament does not know that panel yet -
                     * so Filament::getPanel('app') is null there, and reading
                     * an address off it is a 500 on every page of the panel
                     * rather than a broken link in one menu. Read when the menu
                     * is drawn, every panel is registered and it is a panel.
                     *
                     * Still asked for safely. A panel that is genuinely absent
                     * costs a link, which is the size the problem should be.
                     */
                    ->url(fn (): string => rtrim(Filament::getPanel('app')?->getUrl() ?? '', '/') . '/services')
                    ->visible(fn (): bool => user() !== null),

                Action::make('ld-invoices')
                    ->label(fn (): string => Theme::trans('shop.billing_nav_label'))
                    ->icon('tabler-file-invoice')
                    ->url(fn (): string => rtrim(Filament::getPanel('app')?->getUrl() ?? '', '/') . '/billing')
                    ->visible(fn (): bool => user() !== null),

                /*
                 * What the shop is holding for them, as a figure rather than a
                 * word.
                 *
                 * The label is the amount, because a menu row reading "Credit"
                 * answers nothing: the question people have is how much, and
                 * making them open a page to find out is the reason this row
                 * exists at all.
                 *
                 * Drawn only when there is something to draw. On a panel where
                 * nobody has ever had credit this is a row saying nought to
                 * every user on every page, and one SUM per page to say it.
                 * It goes to the billing page, which is where it can be added
                 * to.
                 */
                Action::make('ld-credit')
                    ->label(fn (): string => Theme::trans('credit.menu', [
                        'amount' => Money::format(Credits::mine(), Packages::currency()),
                    ]))
                    ->icon('tabler-wallet')
                    ->url(fn (): string => rtrim(Filament::getPanel('app')?->getUrl() ?? '', '/') . '/billing')
                    ->visible(fn (): bool => user() !== null
                        && Features::enabled(Features::CREDIT)
                        && Credits::mine() !== 0),
            ]);
        }

        /*
         * Somewhere to ask a question, in the account menu.
         *
         * Its own block rather than a row inside the shop's above, because
         * tickets are not the shop: a panel can want somewhere for people to
         * ask without selling anything, and putting this behind the shop
         * switch would hide it on exactly those panels.
         *
         * In the menu at all because the client panel has no sidebar - the
         * same reason Services and Invoices are there. A page nothing points
         * at is a page with an address and no door, which is what this was.
         */
        if (in_array($panel->getId(), ['app', 'server'], true) && Features::enabled(Features::TICKETS)) {
            $panel->userMenuItems([
                Action::make('ld-tickets')
                    ->label(fn (): string => Theme::trans('tickets.mine_nav_label'))
                    ->icon('tabler-lifebuoy')
                    ->url(fn (): string => rtrim(Filament::getPanel('app')?->getUrl() ?? '', '/') . '/tickets')
                    ->visible(fn (): bool => user() !== null),
            ]);
        }

        /*
         * Pelican's own profile page, with its API keys tab taken out and the
         * customer's billing details folded into Account.
         *
         * Two reasons to hand the panel our class, and either one is enough:
         * a panel that has asked for the API tab to be gone, and a panel with a
         * shop, whose customers need somewhere to put the address that goes on
         * their invoices. Neither can be done from outside the page - a tab is
         * only really gone if it is never built, and nothing appends to a tab
         * somebody else builds.
         *
         * Only where Pelican's class is actually there: our subclass extends it
         * by full path, so a class that moved would be a fatal the moment
         * Filament loaded ours. The ::class below does not load anything - the
         * guard is what decides whether it ever will.
         */
        if (
            (Theme::config('api_hide_pelican', false) || Features::enabled(Features::SHOP))
            && class_exists('App\Filament\Pages\Auth\EditProfile')
        ) {
            $panel->profile(Profile::class, false);
        }

        /*
         * Which of somebody's own servers is behind.
         *
         * The client panel only, and under the same switch as the warning above
         * the server list - they are one feature answering one question in two
         * places, and two switches for one thing is worse than one.
         */
        if ($panel->getId() === 'app' && Features::enabled(Features::MY_BACKUPS)) {
            $panel->pages([MyServers::class]);
        }

        /*
         * Where a customer asks a question.
         *
         * The client panel only. Somebody inside a server has a different
         * sidebar and a different job; asking about the thing you are looking
         * at is what the button on the service card is for.
         */
        if ($panel->getId() === 'app' && Features::enabled(Features::TICKETS)) {
            $panel->pages([MyTickets::class]);
        }


        /*
         * Everything this person has starred, in both panels they might be in.
         *
         * Registered twice rather than once and linked to, because the two
         * panels are different places to be: somebody working in admin should
         * not be sent out to the client panel to look at a list that includes
         * the admin pages they starred. The class is the same and the slug is
         * the same, so the address only differs by which panel it is under -
         * which is exactly what Quick::pageUrl() resolves when it builds the
         * way in from the top bar.
         *
         * Not in the server panel: that one has a tenant in every address, and
         * a list of favourites is not a property of the server you happen to be
         * inside. From there the top bar points at the client panel's copy.
         */
        if (in_array($panel->getId(), ['admin', 'app'], true) && Features::enabled(Features::FAVOURITES)) {
            $panel->pages([Favourites::class]);
        }

        /*
         * And in the user menu, on both panels a person actually sits in.
         *
         * A row in the client panel's sidebar was where this started and it was
         * not enough: people spend their time inside a server, on the console,
         * where that sidebar is a different one. So the way to it goes where
         * "Account" and "Sign out" already are - which is also where somebody
         * looks when they want to change something about themselves rather than
         * about a server.
         *
         * The address is built from the panel rather than from the page, the
         * way Pelican builds its own link to the admin area, because from inside
         * a server the page belongs to a panel this one is not.
         */
        if (in_array($panel->getId(), ['app', 'server'], true) && UserTheme::enabled()) {
            $panel->userMenuItems([
                Action::make('ld-appearance')
                    ->label(fn (): string => Theme::trans('appearance.nav_label'))
                    ->icon('tabler-palette')
                    ->url(fn (): string => rtrim(Filament::getPanel('app')?->getUrl() ?? '', '/') . '/appearance')
                    ->visible(fn (): bool => user() !== null),
            ]);
        }

        /*
         * And the favourites, in the account menu on every panel.
         *
         * The switcher in the top bar is the fast way in and this is the
         * findable one. They are not the same thing: a dropdown that opens on
         * click is not somewhere anybody looks for a feature they have not been
         * told about, and "Account" is where people look for their own things.
         *
         * The address is resolved rather than written, because from inside a
         * server this page belongs to a panel this one is not - the same
         * problem, and the same answer, as the Appearance row above.
         */
        /*
         * A status page of your own, in the account menu on every panel.
         *
         * It was registered as a page in the client panel and nowhere else,
         * which meant it existed and could not be found: the client panel's
         * sidebar is not the sidebar somebody sees while they are inside a
         * server, which is where people actually spend their time. That is the
         * same reason the Appearance row is here rather than only in a sidebar,
         * written down two features ago and not applied to this one.
         *
         * "Account" is also where somebody looks for a thing that belongs to
         * them rather than to a server, which this is.
         */
        if (StatusPages::enabled()) {
            $panel->userMenuItems([
                Action::make('ld-my-status')
                    ->label(fn (): string => Theme::trans('status.mine_nav_label'))
                    ->icon('tabler-world-share')
                    // Built from the panel rather than from the page: inside a
                    // server this belongs to a panel the current one is not.
                    ->url(fn (): string => rtrim(Filament::getPanel('app')?->getUrl() ?? '', '/') . '/my-status')
                    ->visible(fn (): bool => user() !== null),
            ]);
        }

        /*
         * The two that had no way in at all.
         *
         * Pelican's client panel is built with ->navigation(false), so a page
         * registered on it appears in no sidebar and no menu of its own. Seven
         * of this plugin's twelve client pages were given a row here to work
         * around that. These two were not, and nothing else links to them
         * either - they were reachable by typing the address and by nothing
         * else, which for the two pages written specifically for the person
         * whose servers they are is the whole of the feature missing.
         *
         * Each asks its own page whether it should be here rather than reading
         * the switch again, because "may this person open it" is a longer
         * question than "is this on": Needs attention wants the feature, and
         * API access wants the feature and a table that exists.
         */
        if (MyServers::canAccess()) {
            $panel->userMenuItems([
                Action::make('ld-my-servers')
                    ->label(fn (): string => Theme::trans('myservers.nav_label'))
                    ->icon('tabler-alert-triangle')
                    ->url(fn (): string => rtrim(Filament::getPanel('app')?->getUrl() ?? '', '/') . '/my-servers')
                    ->visible(fn (): bool => user() !== null),
            ]);
        }

        if (ApiAccess::canAccess()) {
            $panel->userMenuItems([
                Action::make('ld-api-access')
                    ->label(fn (): string => Theme::trans('api.my_nav_label'))
                    ->icon('tabler-plug-connected')
                    ->url(fn (): string => rtrim(Filament::getPanel('app')?->getUrl() ?? '', '/') . '/api-access')
                    ->visible(fn (): bool => user() !== null),
            ]);
        }

        if (Features::enabled(Features::FAVOURITES)) {
            $panel->userMenuItems([
                Action::make('ld-favourites')
                    ->label(fn (): string => Theme::trans('quick.nav_label'))
                    ->icon('tabler-star')
                    ->url(fn (): string => Quick::pageUrl())
                    ->visible(fn (): bool => user() !== null),
            ]);
        }

        if (Presets::isDisabled()) {
            return;
        }

        $panel->colors([
            'primary' => Palette::accent(),
        ]);

        // Which mode the panel opens in, and whether anyone may change it. Two
        // questions that used to be one switch - see Support\Mode.
        Mode::apply($panel);

        // Pelican sets these in its own panel provider, and plugins are loaded at
        // the end of it, so this overrides rather than fights.
        $height = (float) Theme::config('logo_height', 2);

        if ($height > 0) {
            $panel->brandLogoHeight(round(max(1, min(8, $height)), 2) . 'rem');
        }

        $logo = trim((string) Theme::config('logo_url', ''));

        if ($logo !== '') {
            $panel->brandLogo($logo);
        }

        // Extra rows in this panel's navigation. Here rather than in the
        // provider because which panel this is has to be known, and the
        // argument is the one place it is not a guess.
        if (Features::enabled(Features::NAV_LINKS)) {
            NavLinks::apply($panel);
        }
    }

    public function boot(Panel $panel): void
    {
        $this->guarded(fn () => $this->started($panel));
    }

    /** Everything boot() used to do. See build() above for why it is split. */
    private function started(Panel $panel): void
    {
        // Here rather than in register(): Pelican sets some of these itself
        // while building the panel - the admin panel makes its sidebar
        // collapsible - and boot runs after all of that, so this is the point
        // at which a choice made in the settings actually wins.
        Layout::apply($panel);

        /*
         * And, on the way into any page: has this person lost a role that was
         * giving them servers.
         *
         * Only ever removes, never grants, and that asymmetry is the whole
         * reason it is here rather than left to the timer. Somebody whose role
         * was taken away kept every server it reached until the next sweep,
         * which is the wrong way round for access: granting late is a
         * nuisance, revoking late is not.
         *
         * It costs two cached file reads for anybody this has never granted
         * anything, which is nearly everybody, and it cannot throw into a page.
         */
        try {
            $id = user()?->id;

            if (is_numeric($id)) {
                Sync::revokeStale((int) $id);
            }
        } catch (Throwable) {
            // A page must render whatever this decides.
        }
    }

    /**
     * @return array<string, mixed>
     */
    public function getSettingsFormData(): array
    {
        return Settings::data();
    }

    /**
     * @return array<int, \Filament\Schemas\Components\Component>
     */
    public function getSettingsForm(): array
    {
        return Settings::fields();
    }

    /**
     * @param  array<mixed, mixed>  $data
     */
    public function saveSettings(array $data): void
    {
        /*
         * fields() is every section, so this modal does carry nearly every key.
         * Nearly: a field hidden by its feature being off is not submitted at
         * all, and persist() would write the default over what is stored for it.
         * Which is the one thing switching a feature off must not do.
         */
        Settings::persist(array_merge(Settings::data(), $data));
    }
}
