<?php

/*
 * Dansk. Skrevet i hånden.
 *
 * Butikkens indstillinger, og senere butikken selv.
 *
 * To læsere deler denne fil med vilje. Indstillingshalvdelen læses af
 * administratoren; den offentlige halvdel og kundehalvdelen - som kommer til,
 * efterhånden som butikken vokser - læses af folk, der måske aldrig har hørt
 * om Pelican, og hver sætning dér skal være skrevet til dem.
 */

return [
    'title' => 'Butiksindstillinger',
    'nav_label' => 'Butiksindstillinger',
    'subheading' => 'Valutaen, momsen, hvordan fakturaer nummereres, og hvad den offentlige side siger. Det, der er til salg, står på siden Pakker.',

    // ---- hvor den er -----------------------------------------------------
    'address' => 'Den offentlige butik er på',
    'address_off' => 'Den offentlige side er slået fra. Slå „Offentlig butiksside" til i funktionslisten på siden Essentials-indstillinger, så svarer den på :url.',

    // ---- generelt --------------------------------------------------------
    'section_general' => 'Penge',
    'section_general_helper' => 'Én valuta for hele butikken. Hver pris på hver pakke er et tal i den.',
    'currency' => 'Valuta',
    'currency_helper' => 'At ændre den omregner ingenting: priserne på pakkerne er tal, og efter en ændring er de tal i den nye valuta.',
    'tax' => 'Moms',
    'tax_helper' => 'En procentsats, der lægges på hver faktura som sin egen linje. Priserne på pakkerne er uden moms. Nul for ingen.',
    'tax_suffix' => '%',
    'prefix' => 'Fakturanumre begynder med',
    'prefix_helper' => 'Efterfulgt af et tal, der tæller op. INV- giver INV-000001.',

    // ---- fornyelser ------------------------------------------------------
    'section_renewals' => 'Fornyelser',
    'section_renewals_helper' => 'For pakker, der faktureres pr. måned, kvartal eller år. En engangspakke røres aldrig af dette.',
    'notice_days' => 'Fakturér så mange dage før perioden udløber',
    'notice_days_helper' => 'Hvornår den næste faktura laves, og kunden får besked om den.',
    'grace' => 'Suspendér så mange dage efter, at en faktura forfalder',
    'grace_helper' => 'En ubetalt faktura ud over dette suspenderer serveren — Pelicans egen suspension, ophævet i det øjeblik fakturaen betales. Selve suspenderingen sletter ingenting.',
    'days' => 'dage',

    // ---- den offentlige side ---------------------------------------------
    'section_public' => 'Den offentlige side',
    'section_public_helper' => 'Læses af folk uden konto. Om den overhovedet vises, er kontakten „Offentlig butiksside" i funktionslisten.',
    'heading' => 'Overskrift',
    'heading_helper' => 'Efterlades den tom, bruges panelets eget navn.',
    'note' => 'En linje over pakkerne',
    'note_helper' => 'Til at sige, hvem du er, eller hvad et køb giver nogen. Ren tekst.',
    'terms_url' => 'Vilkår',
    'terms_url_helper' => 'En https-adresse. Er den sat, betyder et køb at sætte kryds i et felt, der peger på den.',

    // ---- at betale i hånden ----------------------------------------------
    'section_manual' => 'Betaling uden udbyder',
    'section_manual_helper' => 'Vises på en ubetalt faktura, så længe ingen betalingsudbyder er slået til: bankoplysninger, eller hvor pengene skal sendes hen. Ren tekst.',
    'pay_note' => 'Sådan betaler man',
    'pay_note_helper' => 'Lad den stå tom, så siger en ubetalt faktura kun, at den er ubetalt.',

    // ---- knapperne -------------------------------------------------------
    'save' => 'Gem',
    'saved' => 'Gemt',
    'save_failed' => 'Intet blev gemt',

    /* ---------------------------------------------------------------------
     * Selve butikken, herfra og ned.
     *
     * En helt anden læser: nogen der køber en server, som måske aldrig har hørt
     * om Pelican og ikke ved, hvad en egg er. Intet herunder bruger panelets
     * ord, og hver sætning svarer på det spørgsmål, en kunde faktisk har det
     * sted på siden.
     * ------------------------------------------------------------------- */

    // ---- butikken --------------------------------------------------------
    'store_title' => 'Butik',
    'store_nav_label' => 'Butik',
    'store_subheading' => 'Vælg en server. Den bliver oprettet til dig, så snart fakturaen er betalt.',
    'store_empty' => 'Der er ikke noget til salg lige nu',
    'store_empty_body' => 'Kom igen senere, eller spørg den, der driver dette panel.',

    'buy' => 'Køb',
    'sold_out' => 'Udsolgt',
    'plus_setup' => 'plus :amount én gang',

    'spec_memory' => ':amount MiB hukommelse',
    'spec_disk' => ':amount MiB disk',
    'spec_cpu' => ':amount% CPU',
    'spec_backups' => ':count sikkerhedskopier',
    'spec_databases' => ':count databaser',

    // ---- den offentlige side ---------------------------------------------
    'public_empty' => 'Der er ikke noget til salg lige nu',
    'public_empty_body' => 'Kom igen senere.',
    'to_panel' => 'Log ind',
    'terms' => 'Betingelser',
    'sign_in_note' => 'Vælg en server nedenfor. Du logger ind for at gøre det færdigt, og den bliver oprettet, når fakturaen er betalt.',

    // ---- bestillingen ----------------------------------------------------
    'checkout_title' => 'Bestilling',
    'tax_line' => 'Moms (:rate%)',
    'coupon' => 'Rabatkode',
    'coupon_placeholder' => 'Hvis du har en',
    'coupon_bad' => 'Den kode virker ikke her.',
    'coupon_good' => 'Koden er brugt.',
    'agree' => 'Jeg accepterer',
    'place_order' => 'Afgiv bestillingen',
    'place_order_note' => 'Dette skriver en faktura. Der bliver ikke trukket noget, før du betaler, og serveren oprettes, når den er betalt.',
    'back_to_store' => 'Tilbage til butikken',

    'placed' => 'Bestillingen er afgivet',
    'placed_body' => 'Faktura :number venter på din faktureringsside.',

    'refused' => 'Det kunne ikke købes',
    'refused_gone' => 'Det er ikke til salg længere.',
    'refused_sold_out' => 'Den sidste er væk.',
    'refused_bad_coupon' => 'Rabatkoden gælder ikke for dette.',
    'refused_failed' => 'Noget gik galt, da bestillingen skulle skrives. Der er ikke trukket noget. Prøv igen, og sig det til den, der driver dette panel, hvis det bliver ved.',

    // ---- fakturering -----------------------------------------------------
    'billing_title' => 'Fakturering',
    'billing_nav_label' => 'Fakturering',
    'billing_subheading' => 'Hvad du har købt, og hvad du skylder.',
    'your_orders' => 'Dine ordrer',
    'your_invoices' => 'Dine fakturaer',
    'no_orders' => 'Du har ikke købt noget endnu',
    'no_orders_body' => 'Alt hvad du køber, står her med sin server og sine datoer.',
    'no_invoices' => 'Ingen fakturaer endnu',
    'to_store' => 'Gå til butikken',
    'renews' => 'Fornyes',
    'ask_how_to_pay' => 'Spørg den, der driver dette panel, hvordan du betaler. De har ikke skrevet det her endnu.',
    'order_pending' => 'Venter på, at fakturaen bliver betalt. Lige derefter oprettes serveren.',
    'order_suspended' => 'Standset på grund af en ubetalt faktura. Betaler du den, starter serveren igen - der er ikke slettet noget.',
    'order_ending' => 'Ophører :date. Den faktureres ikke igen, og alt på den slettes den dag.',
    'order_ending_open' => 'Annulleret. Den faktureres ikke igen og bliver ved med at køre, indtil den fjernes.',

    // ---- at betale -------------------------------------------------------
    'pay_with' => 'Betal med',
    'pay_now' => 'Betal',
    'pay_description' => 'Faktura :number',
    'pay_thanks' => 'Tak. Fakturaen er betalt.',
    'pay_pending' => 'Udbyderen har ikke bekræftet det endnu. Denne side opdaterer sig, så snart de gør.',
    'pay_refused' => 'Det gik ikke i gang',
    'pay_refused_body' => 'Betalingen kunne ikke åbnes. Prøv en anden vej, eller spørg den, der driver dette panel.',
    'gateway_mollie' => 'Mollie',

    // ---- udbyderens indstillinger ----------------------------------------
    'section_mollie' => 'Mollie',
    'section_mollie_helper' => 'Tager iDEAL, kort, Bancontact og resten gennem én konto. Test og live er den samme indstilling: nøglen siger selv, hvilken konto den hører til.',
    'mollie_on' => 'Tilbyd Mollie',
    'mollie_on_helper' => 'Slukket fjerner knappen fra alle fakturaer. Det, der er betalt, bliver ved med at være betalt.',
    'mollie_key' => 'API-nøgle',
    'mollie_key_helper' => 'Fra Developers-afsnittet i dit Mollie-dashboard. Den skrives aldrig ind i en eksporteret indstillingsfil.',
    'mollie_hook' => 'Webhook-adresse',
    'mollie_hook_helper' => 'Mollie melder tilbage til :url - dit panel skal kunne nås der fra internettet.',

    'gateway_stripe' => 'Kort',

    'section_stripe' => 'Stripe',
    'section_stripe_helper' => 'Tager kort på en side, Stripe selv tegner, så et kortnummer aldrig når frem til dette panel. Test og live ligger i nøglens præfiks, ikke i en kontakt.',
    'stripe_on' => 'Tilbyd Stripe',
    'stripe_on_helper' => 'Slukket fjerner knappen fra alle fakturaer. Det, der er betalt, bliver ved med at være betalt.',
    'stripe_key' => 'Hemmelig nøgle',
    'stripe_key_helper' => 'Den, der begynder med sk_, fra Developers, API keys. Skrives aldrig ind i en eksporteret indstillingsfil.',
    'stripe_hook' => 'Signeringshemmelighed',
    'stripe_hook_key_helper' => 'Den whsec_-værdi, Stripe viser, når du tilføjer adressen nedenfor. Uden den kan deres beskeder ikke bevises ægte, og de ignoreres.',
    'stripe_hook_helper' => 'Tilføj :url som endpoint under Developers, webhooks, for hændelsen checkout.session.completed.',

    'gateway_paypal' => 'PayPal',

    'section_paypal' => 'PayPal',
    'section_paypal_helper' => 'Den eneste udbyder, hvor pengene flytter sig, når kunden kommer tilbage, i stedet for mens de stadig er hos PayPal - en lukket fane efterlader altså en ubetalt faktura og ikke en forsvundet betaling.',
    'paypal_on' => 'Tilbyd PayPal',
    'paypal_on_helper' => 'Slukket fjerner knappen fra alle fakturaer. Det, der er betalt, bliver ved med at være betalt.',
    'paypal_sandbox' => 'Testmiljø',
    'paypal_sandbox_helper' => 'Taler med PayPals testkonto i stedet for den rigtige. Deres client ids ser ens ud i begge tilfælde, og det er netop derfor denne kontakt findes.',
    'paypal_id' => 'Client ID',
    'paypal_secret' => 'Secret',
    'paypal_id_helper' => 'Fra den app, du lavede under Apps & Credentials. Se efter, at fanen passer til kontakten ovenfor.',
    'paypal_secret_helper' => 'Ved siden af client ID, bag Show. Skrives aldrig ind i en eksporteret indstillingsfil.',
    'paypal_hook' => 'Webhook-ID',
    'paypal_hook_id_helper' => 'Det ID, PayPal giver webhooken, når du har tilføjet den - ikke adressen. Uden det kan deres beskeder ikke tjekkes hos dem og bliver ignoreret.',
    'paypal_hook_helper' => 'Tilføj :url som webhook på den app, for PAYMENT.CAPTURE.COMPLETED, og indsæt det ID, den får, her.',

    // ---- betalingssiden --------------------------------------------------
    'pay_title' => 'Betal',
    'pay_subheading' => 'Hvad du skylder, og måderne at gøre det op på.',
    'pay_choose' => 'Hvordan vil du betale?',
    'pay_choose_body' => 'Uanset hvad du vælger, afslutter du på deres egen side og kommer lige bagefter tilbage hertil.',
    'pay_safe' => 'Du sendes til udbyderen for at betale. Dine kortoplysninger når aldrig frem til dette panel.',
    'pay_no_ways' => 'Så snart pengene kommer, markeres fakturaen betalt, og din server sættes op.',
    'pay_gone' => 'Den faktura findes ikke',
    'pay_gone_body' => 'Måske er den trukket tilbage, eller adressen er forkert.',
    'pay_already' => 'Denne er betalt',
    'pay_already_body' => 'Der er ikke mere at gøre. Alt, hvad der ventede på den, er allerede på vej.',
    'pay_withdrawn' => 'Denne blev trukket tilbage',
    'pay_withdrawn_body' => 'Den er ude af bøgerne og skal ikke betales. Spørg den, der driver dette panel, hvis det ser forkert ud.',
    'back_to_billing' => 'Tilbage til fakturering',

    'gateway_mollie_note' => 'iDEAL, Bancontact, kort og mere',
    'gateway_stripe_note' => 'Visa, Mastercard, American Express',
    'gateway_paypal_note' => 'Din PayPal-saldo, eller et kort via PayPal',

    // ---- ydelser og fakturaer, hver for sig ------------------------------
    'services_title' => 'Mine ydelser',
    'services_nav_label' => 'Mine ydelser',
    'services_subheading' => 'Det, du betaler for, og den server, hver enkelt blev til.',
    'open_server' => 'Åbn serveren',
    'no_server_yet' => 'Bliver sat op',

    'invoices_title' => 'Fakturaer',
    'invoices_subheading' => 'Hvad du er blevet faktureret, og hvad der står tilbage at betale.',
    'no_invoices_body' => 'Alt, hvad du køber, faktureres her og bliver stående her, efter det er betalt.',

    // ---- butikken som forside --------------------------------------------
    'section_landing' => 'Hvor butikken sidder',
    'section_landing_helper' => 'Om den, der logger ind, lander på butikken eller på sine servere.',
    'landing' => 'Åbn butikken først',
    'landing_helper' => 'Tændt er butikken den første side efter login, og serverlisten rykker ved siden af. Dine ydelser og dine fakturaer er stadig ét klik væk, i butikkens hoved og i kontomenuen. Slukket rykker intet, og butikken er en side som alle andre.',
];
