<?php

/*
 * Nederlands. Met de hand geschreven.
 *
 * Dit is verreweg het grootste taalbestand van de plugin en het is
 * beheerderstekst: uitleg bij instellingen, niet losse knoplabels. Dat maakt het
 * lastiger dan de rest, want de Engelse teksten leggen vaak uit *waarom* iets zo
 * werkt, en dat is precies het deel dat verloren gaat als je woord voor woord
 * vertaalt.
 *
 * Twee keuzes die overal terugkomen:
 *
 *  - Namen van Pelican en Filament blijven staan: node, egg, allocation, panel,
 *    daemon. Iemand die ze opzoekt zoekt die woorden.
 *  - CSS-begrippen ook: hover, backdrop, viewport. Wie eigen CSS schrijft leest
 *    Engels.
 */

return [
    'groups' => [
        'appearance' => 'Weergave',
        'servers' => 'Serverlijst',
        'minecraft' => 'Minecraft',
        'languages' => 'Talen',
        'servers_helper' => 'Hoe een serverkaart wordt getekend. Of ze als raster of als lijst verschijnen is de eigen keuze van elke persoon, onder Account → Dashboardindeling.',
        'server_pages' => 'Serverpagina\'s',
        'server_pages_helper' => 'Wat elke pagina binnen een server draagt, welke pagina het ook is.',
        'console' => 'Consolepagina',
        'console_helper' => 'Het lettertype, de grootte en de hoogte van de terminal zijn de eigen keuze van elke persoon, onder Account.',
        'background' => 'Achtergrond',
        'background_helper' => 'Geldt voor het hele panel, inclusief het inlogscherm.',
        'icons' => 'Iconen',
        'bars' => 'Verbruiksmeters',
        'bars_helper' => 'De processor-, geheugen- en schijfbalken op de serverkaarten.',
        'updates' => 'Updates',
        'updates_helper' => 'Welke releases de Thema-pagina aanbiedt, en waar hij ze zoekt.',
        'brand' => 'Merk',
        'login' => 'Inlogscherm',
        'login_helper' => 'Geldt voor het inloggen, het herstellen van een wachtwoord en tweestapsverificatie.',
        'advanced' => 'Eigen CSS',
        'advanced_helper' => 'Voor alles wat de instellingen hierboven niet dekken. Wordt na al het andere geladen, dus hij wint.',
        'areas' => 'Per gedeelte',
        'areas_helper' => 'Alles hierboven geldt overal. Hier kun je één gedeelte apart zetten; wat je leeg laat blijft de algemene instelling volgen.',
        'footer' => 'Voet van de zijbalk',
        'footer_helper' => 'De onderkant van de zijbalk, die Pelican leeg laat. Alles hier staat uit totdat je het invult.',
        'features' => 'Wat deze plugin toevoegt',
        'features_helper' => 'Een vinkje weghalen haalt het onderdeel volledig uit het panel. De eigen instellingen blijven bewaard en de pagina houdt zijn adres, dus je verliest niets door iets uit te zetten om te zien wat het deed. Elk van deze heeft ook een eigen recht onder Rollen, zodat je er één kunt uitdelen zonder de rest weg te geven. De opmaak zelf staat niet in deze lijst — die heeft een eigen schakelaar, onder Uiterlijk → Weergave → Stijl → Geen.',
        'identity' => 'Deze plugin in de zijbalk',
        'identity_helper' => 'De regel die deze plugin aan de zijbalk toevoegt, en de afbeelding erop.',
    ],

    'pages' => [
        'look' => 'Uiterlijk',
        'look_helper' => 'Kleur, vorm en hoe het panel heet.',
        'pages' => 'Pagina\'s',
        'pages_helper' => 'De serverlijst, de pagina\'s binnen een server, en de terminal.',
        'advanced' => 'Geavanceerd',
        'advanced_helper' => 'De twee noodluiken: je eigen CSS, en instellingen die maar voor één gedeelte gelden.',
        'minecraft' => 'Minecraft',
        'minecraft_helper' => 'Welke eggs Minecraft zijn, en al het andere daarover.',
        'languages' => 'Talen',
        'languages_helper' => 'In welke talen deze plugin antwoordt.',
    ],

    'features' => [
        'look' => 'Uiterlijk-instellingen',
        'look_helper' => 'De regel in de zijbalk voor kleur, vorm en merk.',
        'pages' => 'Pagina-instellingen',
        'pages_helper' => 'De regel in de zijbalk voor de serverlijst, serverpagina\'s en de terminal.',
        'advanced' => 'Geavanceerde instellingen',
        'advanced_helper' => 'De regel in de zijbalk voor je eigen CSS en overschrijvingen per gedeelte.',
        'announcements' => 'Mededelingen',
        'announcements_helper' => 'De balk boven aan het panel.',
        'nav_links' => 'Navigatielinks',
        'nav_links_helper' => 'Je eigen regels in de zijbalk.',
        'login' => 'Inlogscherm',
        'login_helper' => 'De afbeelding, mededeling en links op het inlogscherm.',
        'bars' => 'Verbruiksmeters',
        'bars_helper' => 'De hergekleurde processor-, geheugen- en schijfbalken.',
        'dashboard_status' => 'Versieregel',
        'dashboard_status_helper' => 'De bovenkant van het dashboardblok: welke versie er staat en of er een klaarstaat.',
        'dashboard_nodes' => 'Machines',
        'dashboard_nodes_helper' => 'De rest van het dashboardblok: dit panel en elke node, met wat elk gebruikt.',
        'system_status' => 'Systeemstatuspagina',
        'system_status_helper' => 'De pagina voor de machine waarop het panel zelf draait.',
        'sidebar_footer' => 'Voet van de zijbalk',
        'sidebar_footer_helper' => 'Je eigen regel tekst, de panelversie en één link, onderaan de zijbalk.',
        'languages' => 'Talen',
        'languages_helper' => 'Iedereen antwoorden in de taal die op zijn eigen account staat, voor zover deze plugin daarin vertaald is. Staat dit uit, dan krijgt iedereen Engels.',
        'minecraft' => 'Minecraft',
        'minecraft_helper' => 'Een Minecraft-tab in de zijbalk, en binnen elke Minecraft-server een pagina om server.properties als formulier te bewerken. Welke eggs meetellen bepaal jij.',
        'palworld' => 'Palworld-instellingen',
        'palworld_helper' => 'Een pagina binnen een Palworld-server om de wereldinstellingen te bewerken. Hij verschijnt op geen enkele andere server, en nooit terwijl die server draait.',
        'settings_search' => 'Instellingen zoeken',
        'settings_search_helper' => 'Het vak boven deze formulieren dat ze terugbrengt tot de secties waarin staat wat je typt.',
        'preview' => 'Live voorvertoning',
        'preview_helper' => 'Het vak naast het Uiterlijk-formulier dat laat zien wat de kleuren, hoeken en ruimte doen voordat je ze opslaat.',
        'duplicate' => 'Server dupliceren',
        'duplicate_helper' => 'Een pagina om nog een server precies zo in te richten als eentje die je al hebt, of meerdere tegelijk. Bestanden worden nooit gekopieerd.',
        'favourites' => 'Favoriete servers',
        'favourites_helper' => 'Een ster op elke serverkaart. Servers met een ster komen bovenaan, en de lijst van elke persoon staat op het panel — dus hun sterren gaan mee naar waar ze zich de volgende keer aanmelden. Het verandert wat zij zien en niets voor iemand anders. Op het panel staan betekent wel dat het een bestand onder storage is, dat iedereen met toegang tot de machine kan lezen.',
    ],

    'preview' => [
        'label' => 'Voorvertoning',
        'card' => 'Een kaart',
        'card_helper' => 'Getekend volgens dezelfde regels als het panel, maar met de instellingen op deze pagina in plaats van de opgeslagen.',
        'button' => 'Een knop',
        'field' => 'Een veld',
        'meter_ok' => 'Prima',
        'meter_warning' => 'Let op',
        'meter_danger' => 'Kritiek',

        'full' => 'Het hele panel bekijken',
        'full_confirm' => 'Opent het panel getekend met de instellingen op deze pagina in plaats van de opgeslagen. Er wordt niets weggeschreven — de waarden worden vijftien minuten vastgehouden en het panel gaat terug naar normaal zodra je de voorvertoning verlaat of opslaat.',
        'full_go' => 'Laat zien',
        'full_failed' => 'De voorvertoning kon niet worden gestart',
        'bar' => 'Je kijkt naar niet-opgeslagen instellingen. Er is hier niets weggeschreven.',
        'bar_back' => 'Terug naar de instellingen',
    ],

    'search' => [
        'placeholder' => 'Instellingen zoeken',
        'label' => 'Deze instellingen doorzoeken',
        'none' => 'Niets op deze pagina komt overeen. De instellingen staan verspreid over vier pagina\'s — probeer Uiterlijk, Pagina\'s, Geavanceerd, of Essentials-instellingen.',
    ],

    'footer' => [
        'text' => 'Je eigen regel',
        'text_helper' => 'Platte tekst, maximaal 120 tekens. Wordt geëscaped, net als de mededelingenbalk — dit verschijnt op elke pagina van het panel, en dat maakt het de verkeerde plek om opmaak te accepteren.',
        'version' => 'De panelversie tonen',
        'version_helper' => 'De versie van Pelican, niet die van deze plugin. De plugin noemt de zijne op het dashboard; wat mensen onderaan een zijbalk vragen is naar welk panel ze kijken.',
        'link_label' => 'Linktekst',
        'link_url' => 'Linkadres',
        'link_url_helper' => 'Een http- of https-adres, of een pad van het panel zelf zoals /account. Opent in een nieuw tabblad.',
    ],

    'layout' => [
        'label' => 'Indeling',
        'helper' => 'Hoe het panel is ingedeeld, niet welke kleur het heeft. Geldt voor het beheergedeelte, de serverlijst en het clientgedeelte gelijk. Waar de navigatie komt is een standaard: wie er zelf een heeft gekozen onder Account → Navigatie houdt die.',
        'default' => 'Zijbalk — die van Pelican zelf',
        'rail' => 'Iconenbalk — smal, klapt open bij hover',
        'top' => 'Bovennavigatie — geen zijbalk',
        'mixed' => 'Bovenbalk en zijbalk — allebei',
        'wide' => 'Breed — de inhoud gebruikt het hele scherm',
        'focus' => 'Geconcentreerd — smalle kolom, zijbalk vouwt weg',

        'nav_label' => 'Stijl van de zijbalk',
        'nav_helper' => 'Hoe de zijbalk zelf getekend wordt.',
        'nav_default' => 'Standaard',
        'nav_floating' => 'Zwevend — een eigen kaart',
        'nav_flat' => 'Vlak — helemaal geen achtergrond',
        'nav_bordered' => 'Omlijnd — een lijn, geen vlak',

        'topbar_label' => 'Stijl van de bovenbalk',
        'topbar_helper' => 'Verborgen geldt alleen op desktop — op een telefoon zit in de bovenbalk de enige weg terug naar het menu.',
        'topbar_default' => 'Standaard',
        'topbar_floating' => 'Zwevend — een losse balk',
        'topbar_flush' => 'Aansluitend — vlak, geen vervaging',
        'topbar_hidden' => 'Verborgen op desktop',

        'card_label' => 'Stijl van de kaarten',
        'card_helper' => 'Secties, widgets, serverkaarten en de blokken boven de console.',
        'card_default' => 'Standaard — opgetild met een zachte rand',
        'card_flat' => 'Vlak — geen lift',
        'card_outline' => 'Omlijnd — een rand en niets erachter',
        'card_glass' => 'Matglas — de achtergrond schijnt erdoorheen',
        'card_sharp' => 'Scherp — rechte hoeken',
    ],

    'servers' => [
        'favourite' => 'Deze server een ster geven',
        'favourited' => 'Met ster — komt bovenaan',
        'favourites_tab' => 'Favorieten',
        'favourites_empty' => 'Niets met een ster op deze pagina. Gebruik de ster op een serverkaart om er een toe te voegen — en let op: dit filtert de servers die hier al staan, dus een server met ster op een volgende pagina wordt niet verborgen, hij staat gewoon niet op deze.',

        'art' => 'Spelafbeelding',
        'art_helper' => 'Pelican tekent de afbeelding van de egg op elke kaart. Dit bepaalt wat daarmee gebeurt.',
        'art_faded' => 'Vervaagd — een waas achter de tekst',
        'art_cover' => 'Omslag — achter de naam, uitvloeiend',
        'art_off' => 'Uit',
        'art_dim' => 'De omslag verdonkeren',
        'art_dim_helper' => 'De afbeelding van het ene spel is een heldere lucht en die van het andere een grot.',

        'status' => 'Toestandsmarkering',
        'status_helper' => 'Waar de kleur voor draait/start/gestopt wordt getoond.',
        'status_bar' => 'Balk — langs de linkerrand',
        'status_edge' => 'Rand — over de bovenkant',
        'status_dot' => 'Stip — in de hoek',
        'status_off' => 'Uit',

        'density' => 'Hoogte van de kaart',
        'density_comfortable' => 'Ruim',
        'density_compact' => 'Compact — voor veel servers',

        'filter_label' => 'De filterknop een woord geven',
        'filter_label_helper' => 'Pelican filtert deze lijst al op egg en op eigenaar, over alle pagina\'s heen — maar de ingang is een icoontje zonder tekst naast het zoekvak. Dit zet het woord erop.',
        'filter_button' => 'Filters',

        'columns' => 'Kaarten naast elkaar op een breed scherm',
        'columns_helper' => 'Geldt alleen voor de rasterweergave, en pas vanaf 1280px. Het maximum van Pelican zelf is twee.',
    ],

    'controls' => [
        'mode' => 'Consoleknop op elke serverpagina',
        'mode_helper' => 'Eén zwevende knop, op elke pagina binnen een server. Hij opent de console over waar je mee bezig was, met de toestand en de aan/uit-knoppen in de kop — en bereikt de node rechtstreeks, zoals de serverlijst dat doet, in plaats van via de websocket van de consolepagina. Op de consolepagina zelf verschijnt hij nooit; die heeft alles al.',
        'mode_full' => 'Console en aan/uit-knoppen',
        'mode_console' => 'Alleen de console',
        'mode_off' => 'Uit',
        'label' => 'De knop toont',
        'label_text' => 'Icoon en naam',
        'label_icon' => 'Alleen het icoon',
        'position' => 'Waar hij zweeft',
        'position_helper' => 'Tegen de rand waar je het minst waarschijnlijk zit te lezen.',
        'position_top' => 'Boven',
        'position_right' => 'Rechts',
        'position_bottom' => 'Onder',
    ],

    'console' => [
        'stats' => 'Blokken boven de console',
        'stats_helper' => 'Pelican toont boven de terminal de naam, de status, het adres en de drie verbruikscijfers. Ze verbergen geeft de console die hoogte terug.',
        'stats_tiles' => 'Tegels — label, cijfer en een icoon',
        'stats_plain' => 'Sober — zoals Pelican ze tekent',
        'stats_off' => 'Verborgen',
    ],

    'terminal' => [
        'helper' => 'Wordt aan de terminal zelf meegegeven, dus deze gaan in bij de volgende keer laden en niet op het moment dat je opslaat.',

        'renderer' => 'Getekend door',
        'renderer_helper' => 'Pelican tekent de terminal op de GPU, wat veel sneller is bij een muur aan doorlopende uitvoer. Een browser houdt maar een beperkt aantal GPU-contexten tegelijk in leven — op een telefoon minder — en ruimt de oudste op zodra die grens wordt overschreden; de terminal tekent dan helemaal niets meer, zonder foutmelding. Wordt je console leeg terwijl er verder niets mis lijkt, dan is dit de instelling om aan te passen.',
        'renderer_webgl' => 'De GPU — die van Pelican zelf, sneller',
        'renderer_dom' => 'De browser — trager, tekent altijd',

        'scheme' => 'Kleurenschema',
        'scheme_helper' => 'De enige terminalinstelling die Pelican niet aanbiedt. "Thema volgen" leidt de kleuren af van het accent, en dat is de hele reden dat dit bestaat.',
        'scheme_theme' => 'Thema volgen',
        'scheme_dracula' => 'Dracula',
        'scheme_nord' => 'Nord',
        'scheme_solarized' => 'Solarized Dark',
        'scheme_gruvbox' => 'Gruvbox Dark',
        'scheme_one_dark' => 'One Dark',
        'scheme_tokyo_night' => 'Tokyo Night',
        'scheme_catppuccin' => 'Catppuccin Mocha',
        'scheme_monokai' => 'Monokai',

        'cursor' => 'Cursor',
        'cursor_helper' => 'De console neemt geen invoer aan — het commandovak staat eronder — dus dit is waar de uitvoer ophield, niet waar jij bent.',
        'cursor_underline' => 'Onderstreping — die van Pelican zelf',
        'cursor_block' => 'Blok',
        'cursor_bar' => 'Streep',
        'blink' => 'Knipperende cursor',

        'scrollback' => 'Terugscrollen',
        'scrollback_helper' => 'Hoe ver de console terug te scrollen is. Elke regel wordt in de browser bewaard, dus een spraakzame server met een hoge instelling is echt geheugen op de machine die meekijkt.',
        'scrollback_lines' => ':lines regels',
    ],

    'notice' => [
        'text' => 'Bericht',
        'text_helper' => 'Eén regel, maximaal 200 tekens. Hij wordt geëscaped bij het opslaan én bij het tonen, dus hij kan geen opmaak meedragen naar een pagina die anderen laden.',
        'style' => 'Toon',
        'style_info' => 'Informatie',
        'style_warning' => 'Waarschuwing',
        'style_danger' => 'Dringend',
        'style_accent' => 'Accentkleur',
        'scope' => 'Getoond aan',
        'scope_all' => 'Iedereen',
        'scope_client' => 'Alleen buiten het beheergedeelte',
        'scope_admin' => 'Alleen in het beheergedeelte',
        'link_label' => 'Knoptekst',
        'link_url' => 'Knopadres',
        'link_url_helper' => 'https:// of een pad binnen dit panel, zoals /account. Al het andere wordt genegeerd — een link in een balk op elke pagina is geen plek voor een protocol dat niemand verwachtte.',
        'dismissible' => 'Kan worden gesloten',
        'dismissible_helper' => 'Het sluiten wordt per browser onthouden, en alleen voor dit bericht: verander je de tekst, dan komt hij voor iedereen terug.',
        'dismiss' => 'Sluiten',
    ],

    'preset' => [
        'label' => 'Stijl',
        'helper' => 'Kies een uiterlijk om vanuit te vertrekken. Het vult alles hieronder in, wat je daarna kunt aanpassen. "Geen" zet het thema uit en laat het panel precies zoals Pelican het uitlevert.',
        'options' => [
            'none' => 'Geen - geen thema',
            'legend' => 'Legend - rood vuur naar blauwe bliksem',
            'ember' => 'Ember - warm zwart, oranje accent',
            'midnight' => 'Midnight - diep blauw, rustig',
            'crimson' => 'Crimson - rood, scherpe hoeken, compact',
            'forest' => 'Forest - groen, afgerond, geen gloed',
            'nebula' => 'Nebula - paars met een verlopende achtergrond',
            'terminal' => 'Terminal - groen op zwart, monospace, scherp',
            'console' => 'Console - rond en ruim, voor een tablet',
            'nord' => 'Nord - het Nord-palet, gedempt',
            'solarized' => 'Solarized - Solarized dark, cyaan accent',
            'paper' => 'Paper - licht, hoog contrast, vlak',
            'mono' => 'Mono - grijstinten, vlak en dicht',
        ],
        'save' => 'Opslaan als stijl',
        'save_confirm' => 'Bewaart de kleuren, hoeken, achtergrond, letters, iconen en meterdrempels die je nu op het scherm hebt — onder je eigen naam, in de keuzelijst naast de ingebouwde. Het slaat op wat op de pagina staat, niet wat het laatst is opgeslagen.',
        'save_name' => 'Naam',
        'save_name_helper' => 'Hoe hij in de keuzelijst gaat heten. Opslaan onder een naam die je eerder gebruikte vervangt die.',
        'saved' => 'Stijl opgeslagen',
        'save_failed' => 'Die stijl kon niet worden opgeslagen',
        'save_full' => 'Er is ruimte voor :max eigen stijlen. Verwijder er eerst een.',
        'delete' => 'Een stijl verwijderen',
        'delete_which' => 'Welke',
        'delete_confirm' => 'Alleen je eigen stijlen kunnen worden verwijderd; de ingebouwde niet. Aan hoe het panel er nu uitziet verandert niets — een stijl is een vertrekpunt, en elke waarde die hij zette staat al in de instellingen hieronder.',
        'deleted' => 'Stijl verwijderd',
        'deleted_current' => 'Dat was degene waar dit panel op stond. De instellingen zijn onveranderd en staan nog op deze pagina — kies een stijl, of sla hem opnieuw onder een naam op.',
    ],

    'user_themes' => [
        'label' => 'Stijlen die mensen zelf mogen kiezen',
        'helper' => 'Aangevinkte stijlen verschijnen op een Weergave-pagina in het clientpanel, waar iedereen die is aangemeld er zelf een kan kiezen. Het verandert wat zij zien en niets voor iemand anders. Niets aangevinkt betekent dat niemand iets kiest en het panel één uiterlijk houdt — en dat is wat het nu doet.',
    ],

    'mode' => [
        'label' => 'Panelmodus',
        'helper' => 'In welke modus het panel opent. Wie zelf niets heeft gekozen krijgt deze; met de schakelaar in het gebruikersmenu kunnen ze het nog steeds veranderen, tenzij je dat hieronder vastzet.',
        'dark' => 'Donker',
        'light' => 'Licht',
        'system' => 'Systeem — de eigen instelling van de bezoeker volgen',
    ],

    'font' => [
        'label' => 'Letters in het panel',
        'helper' => 'Elke optie is een familie die het besturingssysteem al heeft — er wordt niets bij een lettertypedienst opgehaald. De terminal blijft buiten schot: dat lettertype is de eigen keuze van elke persoon, onder Account.',
        'default' => 'Standaard - die van Pelican zelf',
        'mono' => 'Monospace',
        'rounded' => 'Afgerond',
        'serif' => 'Schreef',
        'system' => 'Systeem - wat deze machine gebruikt',
    ],

    'surface' => [
        'label' => 'Vlakkleur',
        'helper' => 'De kaarten en panelen. Lichtere en donkerdere tinten worden hiervan afgeleid.',
        'placeholder' => 'Het thema volgen',
    ],

    'radius' => [
        'label' => 'Hoeken',
    ],

    'accent' => [
        'label' => 'Accentkleur',
        'helper' => 'Gebruikt voor knoppen, links, het actieve navigatie-item en focusringen.',
        'contrast_dark' => 'Leesbaarheid: :ratio tegen een donker panel. Onder de 3 is een accent moeilijk te lezen als knop of link — een lichtere tilt het op.',
        'contrast_light' => 'Leesbaarheid: :ratio tegen een licht panel. Onder de 3 is een accent moeilijk te lezen als knop of link — een donkerdere tilt het op.',
    ],

    'density' => [
        'label' => 'Dichtheid',
        'helper' => 'Compact haalt de ruimte aan zodat er meer regels op het scherm passen.',
        'comfortable' => 'Ruim',
        'compact' => 'Compact',
    ],

    'force_dark' => [
        'label' => 'Donkere modus afdwingen',
        'helper' => 'Verbergt de licht/donker-schakelaar en houdt iedereen op het donkere thema.',
    ],

    'glass' => [
        'label' => 'Matglazen bovenbalk',
        'helper' => 'Vervaagt de bovenbalk en de achtergrond achter dialogen. Zet uit op zwakkere apparaten.',
    ],

    'glow' => [
        'label' => 'Accentgloed',
        'helper' => 'Zachte accentschaduw op primaire knoppen, actieve navigatie en de inlogkaart.',
    ],

    'background' => [
        'label' => 'Soort achtergrond',
        'helper' => 'Aurora is de eigen achtergrond van het thema: accentgloed met een fijne korrel.',
        'aurora' => 'Aurora (standaard)',
        'solid' => 'Eén kleur',
        'gradient' => 'Verloop',
        'image' => 'Afbeelding',
        'color' => 'Kleur',
        'color_end' => 'Tweede kleur',
        'angle' => 'Richting',
        'upload' => 'Een afbeelding uploaden',
        'upload_helper' => 'Tot 8 MB. Een geüploade afbeelding gaat voor op de URL hieronder.',
        'url' => 'Of een URL',
        'url_helper' => 'Moet met https:// beginnen en van buitenaf bereikbaar zijn.',
        'dim' => 'Dempen',
        'dim_helper' => 'Zonder demping is witte tekst op een heldere foto onleesbaar.',
        'blur' => 'Vervagen',
    ],

    'channel' => [
        'installed' => 'geïnstalleerd',
        'version' => 'Een bepaalde versie installeren',
        'version_helper' => 'Elke release op dit kanaal, niet alleen de nieuwste — om terug te gaan als iets nieuws slechter blijkt, of vooruit naar een build die je is aangeraden. Alleen zolang updates zichzelf niet installeren: staat dat aan, dan houdt wat je kiest het maar tot de volgende controle vol.',
        'version_placeholder' => 'Kies een versie',
        'version_install' => 'Deze versie installeren',
        'version_confirm' => 'Het panel downloadt die release, bouwt zijn assets opnieuw en leegt zijn caches. Je instellingen blijven behouden. Teruggaan naar een oudere versie mag en wordt niet voor je ongedaan gemaakt — kies de nieuwere opnieuw om weer vooruit te gaan.',
        'label' => 'Updatekanaal',
        'helper' => 'Welke releases de Thema-pagina aanbiedt. Beta krijgt nieuwe versies als eerste, en de ruwe randjes ook.',
        'stable' => 'Stabiel',
        'beta' => 'Beta',
        'dev' => 'Dev (werkbranch)',
        'auto' => [
            'label' => 'Updates automatisch installeren',
            'helper' => 'Uit laat het bijwerken aan jou. Aan controleert het panel het gekozen kanaal en installeert alles wat nieuwer is — het bouwt zijn assets opnieuw terwijl dat loopt en is dan een paar minuten onbereikbaar, dus dagelijks en wekelijks gaan om 04:00. Hiervoor moet de cron van het panel draaien.',
            'interval' => 'Controleren elke',
            'minute' => 'Elke minuut',
            'five_minutes' => 'Elke 5 minuten',
            'ten_minutes' => 'Elke 10 minuten',
            'thirty_minutes' => 'Elke 30 minuten',
            'hourly' => 'Elk uur',
            'daily' => 'Elke dag (04:00)',
            'weekly' => 'Elke week (maandag 04:00)',
        ],
    ],

    'languages' => [
        'section_helper' => 'Pelican laat iedereen al een taal voor zijn account kiezen, en deze plugin volgt die overal waar hij vertaald is. Hier bepaal je welke van die keuzes hij volgt. De meeste talen staan met opzet op een laag percentage: wat als eerste vertaald wordt is het deel dat iedereen op elke pagina ziet — de aan/uit-knoppen boven een console en de node-meters — en de rest komt binnen naarmate mensen eraan bijdragen.',
        'label' => 'Talen om in te antwoorden',
        'helper' => 'Een vinkje weghalen stuurt lezers met die taal op hun account terug naar het Engels, maar alleen voor deze plugin — de rest van het panel spreekt hun taal gewoon. Engels staat er niet bij, omdat alles daarop terugvalt.',
        'done' => ':percent% vertaald',
    ],

    'arranger' => [
        'label' => 'Pagina-indeler',
        'helper' => 'De knop "Pagina indelen", op elke pagina van het panel. Iedereen met het recht Indelen krijgt hem en kan ook de indeling instellen waar alle anderen mee beginnen. Uit verbergt hem voor iedereen; al opgeslagen indelingen blijven staan.',
        'users' => 'Iedereen zijn eigen pagina\'s laten indelen',
        'users_helper' => 'Aan mag iedereen die is aangemeld blokken herschikken en verbergen op de pagina\'s die hij toch al kan zien, alleen voor zichzelf — voor anderen verandert er niets. De indeling waar iedereen mee begint blijft aan het recht Indelen hangen.',
    ],

    'brand' => [
        'logo_height' => 'Hoogte van het logo',
        'logo_height_helper' => 'Pelican levert 2rem. Grotere waarden maken de kop van de zijbalk mee hoger.',
        'logo_url' => 'Logo overschrijven',
        'logo_url_helper' => 'Laat leeg om te houden waar de eigen instellingen van Pelican naar wijzen.',
    ],

    'login' => [
        'image' => 'Achtergrondafbeelding',
        'image_helper' => 'Alleen voor het inlogscherm. Zonder afbeelding blijft de achtergrond van het panel staan.',
        'url' => 'Of een URL',
        'blur' => 'Kaart vervagen',
        'blur_helper' => 'Maakt de kaart matglazig zodat de afbeelding erachter doorschijnt.',
        'width' => 'Breedte van de kaart',
        'position' => 'Positie van de afbeelding',
        'position_helper' => 'Welk deel van de afbeelding overleeft het bijsnijden naar het scherm.',
        'position_center' => 'Midden',
        'position_top' => 'Boven',
        'position_bottom' => 'Onder',
        'position_left' => 'Links',
        'position_right' => 'Rechts',
        'align' => 'Positie van de kaart',
        'align_helper' => 'Waar de inlogkaart over de breedte van het scherm staat.',
        'align_center' => 'Midden',
        'align_start' => 'Links',
        'align_end' => 'Rechts',
        'opacity' => 'Dekking van de kaart',
        'opacity_helper' => 'Lager laat meer van de afbeelding door de kaart heen.',
        'glow' => 'Accentgloed',
        'glow_helper' => 'De halo rond de kaart. Uit houdt zijn rand en zijn diepte.',
        'hide_heading' => 'De kop verbergen',
        'hide_heading_helper' => 'Haalt de titel boven het formulier weg, zodat het formulier alleen overblijft.',
        'hide_footer' => 'De voettekst verbergen',
        'hide_footer_helper' => 'Haalt de regel onder de kaart weg die naar pelican.dev linkt.',
        'above' => 'Regel boven het formulier',
        'above_helper' => 'Eén regel, getoond aan iedereen die op het inlogscherm komt. Laat leeg voor geen.',
        'notice' => 'Mededeling onder de kaart',
        'notice_helper' => 'Eén regel, getoond aan iedereen die op het inlogscherm komt. Laat leeg voor geen.',
    ],

    'advanced' => [
        'css' => 'Eigen CSS',
        'css_helper' => 'Tot 100 KB. Wordt in storage opgeslagen, niet in .env.',
        'reference' => 'CSS-naslag',
        'reference_helper' => 'Elke variabele en class die dit thema en het panel beschikbaar stellen.',
    ],

    'areas' => [
        'add' => 'Een gedeelte toevoegen',
        'area' => 'Gedeelte',
        'inherit' => 'Algemeen',
        'radius' => 'Hoeken',
        'radius_sharp' => 'Scherp',
        'radius_normal' => 'Normaal',
        'radius_round' => 'Rond',
        'surface' => 'Vlakkleur',
        'surface_helper' => 'De kaarten en panelen binnen dit gedeelte; lichtere en donkerdere tinten worden hiervan afgeleid.',
        'names' => [
            'terminal' => 'Terminal',
            'console' => 'Console (de rest van de pagina)',
            'files' => 'Bestandenpagina',
            'edit' => 'Bewerkpagina',
            'server' => 'Overige serverpagina\'s en tabbladen',
        ],
    ],

    'bars' => [
        'base' => 'Basiskleur',
        'base_green' => 'Groen',
        'base_accent' => 'Accentkleur',
        'warning' => 'Oranje vanaf',
        'danger' => 'Rood vanaf',
    ],

    'icons' => [
        'stroke' => 'Lijndikte',
        'stroke_thin' => 'Dun',
        'stroke_normal' => 'Normaal',
        'stroke_bold' => 'Dik',
        'scale' => 'Grootte',
        'accent' => 'Menu-iconen in de accentkleur',
        'accent_helper' => 'Geldt voor de iconen in de zijbalk en de bovenbalk.',
        'pack' => 'Iconenset',
        'pack_helper' => 'Uit welke set de keuzelijst hieronder put. Elke iconenset die op de server is geïnstalleerd wordt aangeboden; kies "Geüploade set" om een eigen set te gebruiken.',
        'pack_custom' => 'Geüploade set',
        'pack_upload' => 'Een set uploaden',
        'pack_upload_helper' => 'Een .zip met SVG-bestanden. Elk bestand wordt een icoon dat naar het bestand heet — logo.svg wordt custom-logo. Uploaden vervangt de set die er nu staat.',
        'overrides' => 'Iconen vervangen',
        'overrides_helper' => 'Eén regel per icoon dat je wilt wijzigen. Links een deel van de link van het menu-item: console, files, backups, schedules, users, databases, network, activity, mounts, startup, settings of webhooks. Rechts zoek je de set hierboven op naam door.',
        'overrides_key' => 'Menu-item',
        'overrides_value' => 'Icoon',
        'overrides_add' => 'Nog een icoon vervangen',
        'overrides_search' => 'Typ om te zoeken…',
    ],

    /*
     * Not under brand. Brand is about how the panel looks; this is about
     * how this plugin appears in it, which is a different question and is
     * answered on a different page.
     */
    'identity' => [
        'nav_icon' => 'Icoon voor de regel Essentials-instellingen',
        'nav_icon_helper' => 'PNG, SVG of ICO, tot 1 MB. Vervangt het icoon op die ene regel in de zijbalk; laat leeg voor het icoon dat deze plugin meelevert. Het wordt als afbeelding getekend en niet als icoon, dus het houdt zijn eigen kleuren in plaats van de tekst te volgen — en dat is meestal wat een logo wil.',
    ],
];
