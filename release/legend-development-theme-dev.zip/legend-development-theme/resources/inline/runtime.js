/*
 * Inlined into the <head> by ThemeServiceProvider, deliberately not built by
 * Vite: it has to run before anything else on the page.
 *
 * Two jobs, both of them races that have to be won:
 *   1. stamp the current area on <html>, before the first paint
 *   2. intercept window.Xterm so the terminal is created with our colours
 *
 * The file editor used to be handled here as well. It is not any more: Monaco
 * styles itself through --vscode-* custom properties, so the stylesheet can do
 * it without any of this timing, and without sitting in the code path that
 * builds the editor.
 *
 * Both parts fail quietly. If Pelican changes how any of this is wired, the
 * panel keeps working with its own colours.
 */
(function () {
    var root = document.documentElement;

    /* ------------------------------------------------------------- colours */

    var canvas = null;

    /**
     * Resolve a custom property to something xterm can parse. It wants hex or
     * rgb and the theme's tokens are oklch, so the canvas is used as the
     * converter - it parses any CSS colour and hands back a hex string.
     */
    function colour(name, fallback) {
        var raw = getComputedStyle(root).getPropertyValue(name).trim();

        if (!raw) {
            return fallback;
        }

        try {
            canvas = canvas || document.createElement('canvas').getContext('2d');
            canvas.fillStyle = '#010203';
            canvas.fillStyle = raw;

            var resolved = canvas.fillStyle;

            if (typeof resolved === 'string' && resolved !== '#010203') {
                return resolved;
            }
        } catch (error) {
            /* fall through */
        }

        return raw.charAt(0) === '#' ? raw : fallback;
    }

    /* ---------------------------------------------------------------- area */

    function area() {
        var match = location.pathname.match(/\/server\/[^/]+(\/.*)?$/);

        if (!match) {
            return '';
        }

        var rest = (match[1] || '').replace(/^\//, '');

        if (rest === '' || rest.indexOf('console') === 0) {
            return 'console';
        }

        if (/^files\/(edit|new)/.test(rest)) {
            return 'edit';
        }

        if (rest.indexOf('files') === 0) {
            return 'files';
        }

        if (/(^|\/)edit(\/|$)/.test(rest)) {
            return 'edit';
        }

        return 'server';
    }

    function stampArea() {
        root.setAttribute('data-ld-area', area());
    }

    /* ------------------------------------------------------------ terminal */

    function terminalTheme() {
        var background = colour('--ld-terminal-bg', '#16130f');
        var accent = colour('--primary-500', '#ffa500');

        return {
            background: background,
            foreground: colour('--ld-terminal-fg', '#d6d3d1'),
            cursor: accent,
            cursorAccent: background,
            selectionBackground: accent + '59',
        };
    }

    /*
     * The size is set here rather than in CSS because xterm draws to a canvas
     * through the WebGL addon: a stylesheet would move the text and leave the
     * glyphs behind.
     *
     * Pelican reads the console's font size from the person's own account
     * settings and hands it to xterm - so this is a ceiling on a screen too
     * narrow for it, never a size of its own. Someone who set 16 keeps 16 at a
     * desk, and gets something that fits on a phone.
     *
     * Worked out from the width rather than in steps, so a fold, a tablet and a
     * phone each get what they have room for. The divisor is roughly what a
     * monospace character costs in width, times the columns worth having: about
     * sixty on a small screen, which is enough for a stack trace to stay on one
     * line.
     */
    function terminalFontSize(current) {
        var size = typeof current === 'number' && current > 0 ? current : 14;
        var width = window.innerWidth || 1024;

        if (width >= 768) {
            return size;
        }

        return Math.max(7, Math.min(size, Math.floor(width / 36)));
    }

    /* Every terminal built on this page, so a rotation can be answered. */
    var terminals = [];

    /*
     * Turning a phone sideways doubles the width, and a size chosen for
     * portrait then wastes half of it. xterm keeps its options on the instance,
     * so the size can be revised - and Pelican's own resize handler calls the
     * fit addon straight after this one, which is what makes it take.
     */
    function refitTerminals() {
        for (var i = 0; i < terminals.length; i++) {
            try {
                var terminal = terminals[i];
                var next = terminalFontSize(terminal.__ldBaseFontSize);

                if (terminal.options.fontSize !== next) {
                    terminal.options.fontSize = next;
                }
            } catch (error) {
                /* a terminal that has been disposed of */
            }
        }
    }

    window.addEventListener('resize', refitTerminals);
    window.addEventListener('orientationchange', refitTerminals);

    /**
     * Pelican builds the terminal from the global Xterm bundle inside a Livewire
     * script block, so the instance is never exposed - but the class is. This
     * intercepts the assignment of that bundle and swaps in a subclass that
     * merges the theme, which works no matter which script runs first.
     */
    function patchXterm(bundle) {
        if (!bundle || !bundle.Terminal || bundle.__ldPatched) {
            return bundle;
        }

        var Base = bundle.Terminal;

        bundle.Terminal = class extends Base {
            constructor(options) {
                var merged = Object.assign({}, options || {});

                var base = merged.fontSize;

                try {
                    merged.theme = Object.assign({}, merged.theme, terminalTheme());
                    merged.fontSize = terminalFontSize(base);
                } catch (error) {
                    /* keep Pelican's own theme */
                }

                super(merged);

                try {
                    // What the account settings asked for, kept so a rotation
                    // is measured against it rather than against the last
                    // narrow answer.
                    this.__ldBaseFontSize = base;

                    terminals.push(this);
                } catch (error) {
                    /* not fatal: the terminal simply will not follow a rotation */
                }
            }
        };

        bundle.__ldPatched = true;

        return bundle;
    }

    var xterm = window.Xterm;

    try {
        Object.defineProperty(window, 'Xterm', {
            configurable: true,
            get: function () {
                return xterm;
            },
            set: function (value) {
                xterm = patchXterm(value);
            },
        });
    } catch (error) {
        /* another script already locked the property */
    }

    if (xterm) {
        patchXterm(xterm);
    }


    /* --------------------------------------------------------------- start */

    stampArea();


    document.addEventListener('livewire:navigated', stampArea);
})();
