{{--
    The panel's own machine, and any node you asked to see beside it.

    Every figure is worked out in the page class, the same way the node health
    widget does it - a view that calls into the theme's own classes is a view
    that can throw halfway through the markup, which is the one place there is
    no good way to report it.

    The whole page re-renders on the chosen interval rather than each card
    asking for itself: one request beats six, and every reading comes from the
    same moment that way.
--}}
<x-filament-panels::page>
    <div class="ld-system" @if ($refresh) wire:poll.{{ $refresh }}s @endif>
        @foreach ($sections as $section)
            <section class="ld-system__section">
                {{-- The heading earns its place only when there is a second
                     section for it to tell apart. --}}
                @if (count($sections) > 1)
                    <h2 class="ld-system__heading">{{ $section['title'] }}</h2>
                @endif

                <div class="ld-system__grid">
                    @foreach ($section['cards'] as $card)
                        <article class="ld-system__card" data-level="{{ $card['level'] }}">
                            <header class="ld-system__head">
                                <x-filament::icon :icon="$card['icon']" class="ld-system__icon" />
                                <h3 class="ld-system__label">{{ $card['label'] }}</h3>

                                @if (($card['flag'] ?? null) !== null)
                                    <span class="ld-system__flag ld-system__flag--{{ $card['flag_kind'] ?? 'maintenance' }}">{{ $card['flag'] }}</span>
                                @endif
                            </header>

                            @if ($card['kind'] === 'facts')
                                <dl class="ld-system__facts">
                                    @foreach ($card['facts'] as $fact)
                                        <dt>{{ $fact['label'] }}</dt>
                                        <dd title="{{ $fact['value'] }}">{{ $fact['value'] }}</dd>
                                    @endforeach
                                </dl>
                            @elseif ($card['kind'] === 'missing')
                                <p class="ld-system__missing">{{ $card['figure'] }}</p>
                            @else
                                @if ($card['figure'] !== '')
                                    <p class="ld-system__figure">{{ $card['figure'] }}<span
                                        class="ld-system__unit">{{ $card['unit'] }}</span></p>
                                @endif

                                {{-- Pinned to the bottom, so the bars of a row
                                     of cards sit on one line however many lines
                                     of detail each of them carries. --}}
                                <div class="ld-system__foot">
                                    @if ($card['kind'] === 'meter')
                                        <span class="ld-system__bar" style="--ld-fill: {{ $card['fill'] }}%"></span>
                                    @endif

                                    @foreach ($card['details'] as $detail)
                                        <p class="ld-system__detail">{{ $detail }}</p>
                                    @endforeach

                                    @foreach ($card['meters'] as $meter)
                                        <div class="ld-system__sub" data-level="{{ $meter['level'] }}">
                                            <span class="ld-system__sub-label">{{ $meter['label'] }}</span>
                                            <span class="ld-system__bar ld-system__bar--sub"
                                                  style="--ld-fill: {{ $meter['fill'] }}%"></span>
                                            <span class="ld-system__sub-value">{{ $meter['value'] }}</span>
                                        </div>
                                    @endforeach
                                </div>
                            @endif
                        </article>
                    @endforeach
                </div>
            </section>
        @endforeach
    </div>
</x-filament-panels::page>
